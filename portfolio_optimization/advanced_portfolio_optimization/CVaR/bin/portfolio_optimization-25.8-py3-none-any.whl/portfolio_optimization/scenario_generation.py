'''
SPDX-FileCopyrightText: Copyright (c) 2021-2025 NVIDIA CORPORATION &
AFFILIATES. All rights reserved. SPDX-License-Identifier:
LicenseRef-NvidiaProprietary

NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
property and proprietary rights in and to this material, related
documentation and any modifications thereto. Any use, reproduction,
disclosure or distribution of this material and related documentation
without an express license agreement from NVIDIA CORPORATION or
its affiliates is strictly prohibited.
'''

import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

class ForwardPathSimulator:
    """
    Fit a multivariate geometric Brownian motion (log-normal process)
    and draw forward scenarios.

    Parameters
    ----------
    fitting_data : pd.DataFrame
        Historical time series with a DatetimeIndex (rows = dates,
        columns = assets or currency pairs). Used for calibration.
    generation_dates : pd.DatetimeIndex
        Ordered dates **including** the first date that anchors simulation.
    n_paths : int
        Number of Monte-Carlo scenarios to generate.
    method : str, default 'log_gbm'
        Generation method. Only `'log_gbm'` is currently implemented.

    Attributes
    ----------
    simulated_paths : np.ndarray
        Shape = (n_paths, n_steps + 1, n_assets). Populated after ``generate``.
    """
    def __init__(self, fitting_data, generation_dates, n_paths,  method = 'log_gbm'): 
        self.fitting_data = fitting_data           # (n_dates_fit, n_assets)
        self.dates = generation_dates              # Future timeline to simulate
        self.n_steps = len(generation_dates) - 1   # Time steps to generate
        self.n_paths = n_paths                     # Scenario count
        self.generation_method = method.lower()    # Normalise switch argument
        
    def generate(self, plot_paths = False, n_plots = 0):
        """
        Calibrate the chosen stochastic process and populate ``self.simulated_paths``.

        Parameters
        ----------
        plot_paths : bool, default False
            If *True*, produce quick-look charts for `n_plots` randomly chosen scenarios.
        n_plots : int, default 0
            How many scenarios to visualise (ignored when ``plot_paths`` is False).

        Raises
        ------
        ValueError
            If an unsupported generation method is requested.
        """
        if self.generation_method == 'log_gbm':
            # 1) Calibrate to historical log-returns
            mu, sigma, L = self._calibrate_log_process()
            # 2) Draw forward paths under the fitted GBM
            self.simulated_paths = self._generate_via_log_gbm(mu, sigma, L)
        else: 
            raise ValueError('Unrecognized generation method.')

        # 3) Optional exploratory plots
        if plot_paths: 
            self._plot_generated_paths(n_plots)
    
    def _calibrate_log_process(self):
        """
        Estimate per-step drift and volatility matrix from historical data.

        Returns
        -------
        mu : np.ndarray
            Per-step drift vector (length = n_assets).
        sigma : np.ndarray
            Covariance matrix of log-returns (n_assets × n_assets).
        L : np.ndarray
            Transposed Cholesky factor such that ``Z @ L`` imposes correlations
            when `Z` ~ N(0, I).
        """
        # Compute log-returns and drop first NaN row created by the shift
        log_returns = np.log(self.fitting_data / self.fitting_data.shift(1)).dropna()
         
        # Sample covariance matrix of log-returns
        sigma = log_returns.cov().values
        # Cholesky factor (upper-triangular because we transpose later)
        L = np.linalg.cholesky(sigma).T

        # Drift: distribute total historical log-return evenly across future steps
        # and add +0.5 Var term so that expected level matches arithmetic GBM mean
        total_drift = log_returns.iloc[-1].values - log_returns.iloc[0].values
        step_drift = total_drift / self.n_steps
        mu = step_drift + 0.5 * np.sum(L**2, axis = 1)
        
        return mu, sigma, L
    
    def _generate_via_log_gbm(self, mu, sigma, L, dt = 1):
        """
        Draw paths under a correlated geometric Brownian motion.

        Notes
        -----
        • Uses Euler-exact discretisation (closed-form transition for GBM).
        • ``dt`` is anchored to the spacing of *generation_dates* supplied
          at construction time.

        Returns
        -------
        np.ndarray
            Simulated cube with shape (n_paths, n_steps + 1, n_assets).
        """
        # Vector of initial levels (index 0 of generation_dates)
        last_rates = self.fitting_data.loc[self.dates[0]].values

        simulated_paths = np.zeros((self.n_paths, self.n_steps+1, len(mu)))
        current_rates = last_rates
        simulated_paths[:, 0, :] = current_rates

        # Draw independent standard normals, then inject correlation via L
        Z = np.random.normal(size = (self.n_paths, self.n_steps, len(mu))) 
        dW = np.matmul(Z, L) * np.sqrt(dt)

        for t in range(1, self.n_steps+1):
            # Drift minus half variance (Ito correction) times dt
            drift = (mu - 0.5 * np.diag(sigma)**2) * dt
            diffusion = dW[:,t-1,:]
            
            # Geometric Brownian motion exact step
            simulated_paths[:, t, :] = simulated_paths[:,t-1,:] * np.exp(drift + diffusion)

        return simulated_paths

    def _plot_generated_paths(self, n_plots):
        """
        Quick diagnostic plot—NO effect on internal state.

        Parameters
        ----------
        n_plots : int
            Number of scenarios to display. Must not exceed ``self.n_paths``.
        """
        # Assuming 'simulated_paths' is your array of simulated paths with shape (n_paths, n_steps, n_ccy_pairs)
        n_paths = self.simulated_paths.shape[0]
        n_ccy_pairs = self.simulated_paths.shape[2]

        # Randomly select indices for the scenarios to plot
        random_indices = np.random.choice(n_paths, n_plots, replace=False)
        plt.rcParams.update({'font.size': 8})
        sns.set(rc={"figure.dpi":100, 'savefig.dpi':300})
        sns.set_palette(palette="tab10")
        sns.set_style('white')
        
        # Loop through each selected scenario and create a subplot
        for i, idx in enumerate(random_indices):
            plt.figure(i, figsize = (10,7))

            # Convert selected scenario to DataFrame for easy plotting
            selected_paths = pd.DataFrame(self.simulated_paths[idx, :, :], index = self.fitting_data.index, columns = self.fitting_data.columns)
            
            selected_paths.plot()
            
            plt.title(f'Scenario {i+1} - Path {idx+1}')
#             plt.xlabel('Time Step')
            plt.xticks(rotation=50, fontsize = 8)

            plt.ylabel('Forward Rate')
            plt.legend()
            
            plt.show()
            
    def get_simulated_paths_ccy_pair(self, ccy_pair):
        """
        Retrieve *all* simulated scenarios for a single asset / currency pair.

        Parameters
        ----------
        ccy_pair : str
            Column name present in ``fitting_data``.

        Returns
        -------
        pd.DataFrame
            Index = generation_dates, columns = scenario number,
            values = simulated forward rates.
        """
        ccy_pair_idx = list(self.fitting_data.columns).index(ccy_pair)
        simulated_paths_ccy_pair = self.simulated_paths[:,:, ccy_pair_idx]
        simulated_paths_dataframe = pd.DataFrame(simulated_paths_ccy_pair, index = self.dates)
        
        return simulated_paths_dataframe


def generate_synthetic_stock_data(dataset_directory, num_synthetic, fit_range, generate_range):
    """
    Fit GBM to a *subset* of a dataset and augment another period with
    synthetic assets.

    The function is intentionally simple: it multiplies the asset universe by
    ``num_synthetic`` without re-ranking or feature-engineering the outputs.
    Perfect for data-hungry deep-learning models where sheer volume often
    trumps marginal realism.

    Parameters
    ----------
    dataset_directory : str
        Path to a CSV where index = timestamp and each column is a ticker.
    num_synthetic : int
        Multiplier for synthetic replication. Total new assets created will be
        ``num_synthetic × n_assets``.
    fit_range : tuple(str, str)
        Two ISO date strings ``(start, end)`` defining the training slice.
    generate_range : tuple(str, str)
        Two ISO date strings ``(start, end)`` defining the time window to
        populate with *both* the real data slice and the synthetic augmentation.

    Returns
    -------
    pd.DataFrame
        Combined real + synthetic dataset with appropriately suffixed column
        names (e.g. `"MSFT-3"` means the 4th synthetic path for MSFT).
    """
    # --------------------------------------------------------------------- #
    # 1. Load & slice data
    # --------------------------------------------------------------------- #
    input_data = pd.read_csv(dataset_directory, index_col = 0)
    # Historical segment used for calibration
    fit_data = input_data.loc[fit_range[0]:fit_range[1]]
    n_assets = len(fit_data.columns)
    # Dates to be filled by the generator
    generate_time_range = input_data.loc[generate_range[0]:generate_range[1]].index

    # --------------------------------------------------------------------- #
    # 2. Calibrate simulator on the chosen slice
    # --------------------------------------------------------------------- #
    scen_gen = ForwardPathSimulator(fitting_data = fit_data, generation_dates = generate_time_range, n_paths = num_synthetic,  method = 'log_gbm')
    
    scen_gen.generate()

    # --------------------------------------------------------------------- #
    # 3. Re-shape: (n_steps+1, n_paths × n_assets)
    # --------------------------------------------------------------------- #
    synthetic_data = scen_gen.simulated_paths.transpose(1,0,2).reshape(scen_gen.n_steps+1, (scen_gen.n_paths * n_assets))

    # --------------------------------------------------------------------- #
    # 4. Merge real and synthetic data
    # --------------------------------------------------------------------- #
    tickers_list = list(input_data.columns)
    
    synthetic_dataframe = pd.DataFrame(synthetic_data, index = generate_time_range)
    
    augmented_data = pd.concat([input_data.loc[generate_range[0]:generate_range[1]], synthetic_dataframe], axis = 1)

    # Name new columns as "<TICKER>-<synthetic_idx>"
    columns = [ticker + '-' + str(idx) for idx in range(scen_gen.n_paths) for ticker in tickers_list]
    tickers_list += columns 
    augmented_data.columns = tickers_list
    
    return augmented_data

