'''
SPDX-FileCopyrightText: Copyright (c) 2021-2025 NVIDIA CORPORATION &
AFFILIATES. All rights reserved. SPDX-License-Identifier:
LicenseRef-NvidiaProprietary

NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
property and proprietary rights in and to this material, related
documentation and any modifications thereto. Any use, reproduction,
disclosure or distribution of this material and related documentation
without an express license agreement from NVIDIA CORPORATION or
its affiliates is strictly prohibited.
'''

from dataclasses import dataclass
import datetime as dt
import os
import json

import numpy as np
import pandas as pd
import math
import scipy
from scipy.stats import norm
from scipy.sparse import csr_matrix
import sklearn.neighbors
import cuml.neighbors
import cvxpy as cp

import matplotlib.pyplot as plt
import seaborn as sns

from . import utils, base_optimizer, cvar_optimizer, scenario_generation
from .portfolio import Portfolio

FILE_FORMAT = '.json'

def calculate_returns(file_name, regime_dict, return_type, cvar_params, device = 'CPU'):
    """
    Wrapper that converts raw price data → returns → CVaR-ready scenario data.

    Parameters
    ----------
    file_name : str
        Path to the input CSV/Parquet containing price history.
    regime_dict : dict
        Dict with keys ``'name'`` and ``'range'`` describing the regime slice.
    return_type : str
        Return calculation to perform, e.g. ``'LOG'`` or ``'ARITH'``.
    cvar_params : CVaR_Parameters
        Object carrying user-selected scenario generation options.
    device : {'CPU', 'GPU'}, default 'CPU'

    Returns
    -------
    dict
        Same structure as ``returns_dict`` returned by
        :pyfunc:`utils.calculate_returns`, but augmented with a
        ``'cvar_data'`` field holding a :class:`cvar_optimizer.CVaR_Data`
        instance ready for optimisation.
    """
    returns_dict = utils.calculate_returns(file_name, regime_dict, return_type)
    cvar_returns_dict = generate_CVaR_data(returns_dict, cvar_params, device = 'CPU')
    
    return cvar_returns_dict

def generate_samples_kde(num_scen, returns_data, bandwidth, kernel='gaussian', device = 'CPU'):
    """
    Draw synthetic return scenarios from a kernel-density estimate.

    Parameters
    ----------
    num_scen : int
        Number of synthetic scenarios to sample.
    returns_data : ndarray of shape (n_obs, n_assets)
        Historical asset returns.
    bandwidth : float
        Kernel bandwidth.  Use cross-validation upstream if unsure.
    kernel : str, default 'gaussian'
        Kernel shape supported by Sklearn and cuML ``KernelDensity``.
    device : {'CPU', 'GPU'}, default 'CPU'
        Chooses implementation – Sklearn on CPU vs. cuML on GPU.

    Returns
    -------
    ndarray of shape (num_scen, n_assets)
        Sampled log-return scenarios.

    Raises
    ------
    ValueError
        If ``device`` is not one of the accepted values.
    """
    if device == 'CPU':
        kde = sklearn.neighbors.KernelDensity(kernel=kernel, bandwidth=bandwidth).fit(returns_data)
    elif device == 'GPU':
        kde = cuml.neighbors.KernelDensity(kernel=kernel, bandwidth=sbandwidth).fit(returns_data)
    else: 
        raise ValueError('Invalid Device: CPU or GPU!')
    new_samples = kde.sample(num_scen)

    return new_samples

def generate_CVaR_data(returns_dict, cvar_params, device = 'CPU'):
    """
    Assemble a :class:`cvar_optimizer.CVaR_Data` object from raw returns.

    Parameters
    ----------
    returns_dict : dict
        Output of :pyfunc:`utils.calculate_returns`.  Must contain keys
        ``'mean'``, ``'covariance'`` and ``'returns'``.
    cvar_params : CVaR_Parameters
        Holds the scenario generation hyper-parameters.
    device : {'CPU', 'GPU'}, default 'CPU'
        Used only when ``fit_type == 'kde'``.

    Returns
    -------
    dict
        Same as ``returns_dict`` plus a new key ``'cvar_data'`` pointing to
        a fully-populated :class:`cvar_optimizer.CVaR_Data` instance.

    Notes
    -----
    * For ``fit_type == 'historical'`` the user-supplied observations are
      treated as scenarios verbatim – no resampling.
    * ``cvar_params.update_num_scen`` is called automatically when
      historical data length ≠ user-requested ``num_scen``.
    """
    return_mean = returns_dict['mean']
    covariance = returns_dict['covariance']
    returns_data = returns_dict['returns']
    num_scen = cvar_params.num_scen
    fit_type = cvar_params.fit_type
    
    if fit_type == 'gaussian': # Multivariate-normal bootstrap
        R_log = np.random.multivariate_normal(return_mean, covariance, size = num_scen)
        R = np.transpose(R_log)
        p = np.ones(num_scen) / num_scen # probability of each scenario

    elif fit_type == 'kde': # Non-parametric resampling via KDE
        R_log = generate_samples_kde(num_scen, returns_data, bandwidth=0.005, kernel='gaussian', device = device)
        R = np.transpose(R_log)
        p = np.ones(num_scen) / num_scen #probability of each scenario

    elif fit_type == 'historical': # Use raw observations as scenarios
        R = np.transpose(returns_data)
        num_scen = R.shape[1]
        p = np.ones(num_scen) / num_scen
        cvar_params.update_num_scen(num_scen)
    else: 
        raise ValueError('Unsupported fit type: must be from gaussian, kde, or historical.')
        
    cvar_data = cvar_optimizer.CVaR_Data(mean = return_mean,
                     covariance = covariance,
                     R = R,
                     p = p)
    
    returns_dict['cvar_data'] = cvar_data
    
    return returns_dict


def optimize_market_regimes(input_file_name, return_type, all_regimes, cvar_params, problem_from_folder = None,
                            gpu_settings = None, cpu_settings = None, device = 'CPU', results_csv_file_name = None,
                            num_synthetic = 0): 
    """
    Benchmark CPU vs. GPU CVaR optimisation on a set of market regimes.

    The routine can *optionally* create synthetic price data on-the-fly,
    run the solver(s), and dump performance metrics to CSV.

    Parameters
    ----------
    input_file_name : str
        Path to historical price data (CSV/Parquet).
    return_type : str
        Return calculation (e.g. ``'LOG'``).
    all_regimes : dict
        ``{'regime_name': (start_date, end_date)}``.
    cvar_params : CVaR_Parameters
        Hyper-parameters for the CVaR solver & scenario generation.
    problem_from_folder : str or None, optional
        If set, skip model build and load an existing cuOpt JSON instead.
        The folder **must** contain one file per regime with the naming
        scheme ``{regime}-num_scen{N}.json``.
    gpu_settings, cpu_settings : dict or None
        Forwarded verbatim to :pyfunc:`cvar_optimizer.CVaR.solve_optimization_problem`.
    device : {'CPU', 'GPU', 'BOTH'}, default 'CPU'
        Where to solve.  'BOTH' runs each regime once per device.
    results_csv_file_name : str or None
        If provided, the aggregated dataframe is persisted here.
    num_synthetic : int, default 0
        On-the-fly generation of *additional* synthetic datasets using
        :pyfunc:`create_synthetic_stock_dataset`.

    Returns
    -------
    pandas.DataFrame
        One row per regime (per device if ``device == 'BOTH'``) with timing
        and performance deltas.

    Raises
    ------
    FileNotFoundError
        If ``problem_from_folder`` is not an existing directory.
    ValueError
        On unsupported ``device`` selection.
    """
    device = device.upper()

    # Column layout depends on benchmarking mode
    if device == 'CPU' or device == 'GPU':
        columns = ['device', 'regime', 'solve time', 'obj', 'return', 'CVaR', 'optimal portfolio']
        result_dataframe = pd.DataFrame(columns=columns)
    elif device == 'BOTH':
        columns = ['regime', 'cpu_time', 'gpu_time', 'obj_gap(CPU - GPU)', 'return_gap', 'CVaR_gap', 'cpu optimal portfolio', 'gpu optimal portfolio']
        result_dataframe = pd.DataFrame(columns=columns)

    # ------------------------------------------------------------------
    # Loop over regimes
    # ------------------------------------------------------------------
    for regime_name, regime_range in all_regimes.items():
        print("========================================")

        # Synthetic data generator (stress-test scalability)
        if num_synthetic > 0:
            input_data_directory = create_synthetic_stock_dataset(input_file_name, regime_name, regime_range, num_synthetic)
        else:
            input_data_directory = input_file_name
            
        # ------------------------------------------------------------------
        # 1) Scenario generation
        # ------------------------------------------------------------------
        curr_regime = {'name': regime_name, 'range': regime_range}
        returns_dict = calculate_returns(input_data_directory, curr_regime, return_type, cvar_params)
        
        # ------------------------------------------------------------------
        # 2) Problem set-up / restore
        # ------------------------------------------------------------------
        if problem_from_folder is None: 
            cvar_problem = cvar_optimizer.CVaR(returns_dict = returns_dict, cvar_params = cvar_params)
        else: 
            if not os.path.isdir(problem_from_folder):
                raise FileNotFoundError(f"The directory '{directory}' does not exist or is not a directory.")
            else: 
                problem_from_file = problem_from_folder + "/" + regime_name + '-' + 'num_scen' + str(cvar_params.num_scen)
            
            cvar_problem = cvar_optimizer.CVaR(returns_dict = returns_dict, cvar_params = cvar_params, problem_from_file = problem_from_file)

        # ------------------------------------------------------------------
        # 3) Solve
        # ------------------------------------------------------------------
        if device != 'BOTH':
            result, portfolio = cvar_problem.solve_optimization_problem(device = device, cpu_settings = cpu_settings, gpu_settings = gpu_settings)
            
            result['optimal portfolio'] = portfolio.print_clean(verbose=False)
            result['device'] = device
            result_dataframe = pd.concat([result_dataframe, result.to_frame().T])

        
        else: # Benchmark both devices
            cpu_result, cpu_portfolio = cvar_problem.solve_optimization_problem(device = 'CPU', cpu_settings = cpu_settings, gpu_settings = gpu_settings)
            gpu_result, gpu_portfolio = cvar_problem.solve_optimization_problem(device = 'GPU', cpu_settings = cpu_settings, gpu_settings = gpu_settings)
            
            result = pd.Series({'regime': regime_name, 'cpu_time': cpu_result['solve time'], 'gpu_time': gpu_result['solve time'], 'obj_gap(CPU - GPU)': cpu_result['obj'] - gpu_result['obj'],\
                     'return_gap': cpu_result['return'] - gpu_result['return'], 'CVaR_gap': cpu_result['CVaR'] - gpu_result['CVaR']})
            result['cpu optimal portfolio'] = cpu_portfolio.print_clean(verbose=False)
            result['gpu optimal portfolio'] = gpu_portfolio.print_clean(verbose=False)            
            result_dataframe = pd.concat([result_dataframe, result.to_frame().T])
            
            
    result_dataframe.reset_index(drop = True, inplace = True)

    if results_csv_file_name: 
        result_dataframe.to_csv(results_csv_file_name)

    return result_dataframe

def create_synthetic_stock_dataset(training_directory, regime_name, regime_range, num_synthetic):
    """
    Wrapper around :pyfunc:`scenario_generation.generate_synthetic_stock_data`.

    Parameters
    ----------
    training_directory : str
        Directory with the *original* historical dataset used for fitting.
    regime_name : str
        Name to embed in the generated file.
    regime_range : tuple(str, str)
        (start_date, end_date) used both for fitting and generation.
    num_synthetic : int
        Number of synthetic time-series to append.

    Returns
    -------
    str
        Absolute path to the freshly-created CSV file.

    Raises
    ------
    ValueError
        If ``num_synthetic`` ≤ 0.
    """
    if num_synthetic <= 0:
        raise ValueError('Please provide a valid integer for num_synthetic!')

    synthetic_data = scenario_generation.generate_synthetic_stock_data(dataset_directory=training_directory,\
                                                           num_synthetic=num_synthetic,\
                                                           fit_range = regime_range,\
                                                           generate_range = regime_range)
    dataset_size = len(synthetic_data.columns)

    save_name = 'synthetic-' + regime_name + f'-size_{dataset_size}.csv'
    save_path = os.path.join(os.path.dirname(training_directory), save_name)
    synthetic_data.to_csv(save_path)

    return save_path


def generate_file_market_regimes(input_file_name, return_type, all_regimes, cvar_params, folder_name = None): 
    """
    Generate JSON problem instances for **cuOpt** *without* solving them.

    One JSON per ``regime`` is stored into ``folder_name``.

    Parameters
    ----------
    input_file_name : str
        Historical price file.
    return_type : str
        See :pyfunc:`utils.calculate_returns`.
    all_regimes : dict
        Mapping of names → date ranges.
    cvar_params : CVaR_Parameters
        Scenario generation + optimisation hyper-parameters.
    folder_name : str, optional
        Target directory.  Must be provided.

    Raises
    ------
    ValueError
        If ``folder_name`` is omitted.
    """
    if folder_name is None: 
        raise ValueError('Need to provide a folder directory!')
    else: 
        os.makedirs(folder_name, exist_ok=True)
        
    for regime_name, regime_range in all_regimes.items():
        curr_regime = {'name': regime_name, 'range': regime_range}
        returns_dict = calculate_returns(input_file_name, curr_regime, return_type, cvar_params)
        
        cvar_problem = cvar_optimizer.CVaR(returns_dict = returns_dict, cvar_params = cvar_params)
        
        file_name = regime_name + '-num_scen' + str(cvar_params.num_scen)
        to_file = (folder_name, file_name)
            
        cvar_problem._save_problem_for_cuopt(to_file)
        print(f'File generated at: {folder_name}/{file_name}' + FILE_FORMAT)

def convert_to_compliant(value):
    """
    Helper – normalise Python scalars so they survive JSON round-trip.

    ``cuOpt`` expects strings ``'NaN'``, ``'inf'``, ``'ninf'`` for special float values.

    Parameters
    ----------
    value : Any

    Returns
    -------
    Any
        Converted value suitable for JSON serialisation.
    """
    if isinstance(value, float):
        if np.isnan(value):
            return 'NaN'
        elif np.isinf(value):
            if value > 0:
                return 'inf'
            else:
                return 'ninf'
    return value

def convert_from_file(value):
    if value == 'inf':
        return np.inf
    elif value == 'ninf':
        return -np.inf
    else: 
        return value

def evaluate_portfolio_performance(cvar_data, portfolio, confidence_level):
    """
    Compute *ex-ante* performance metrics for a fixed portfolio.

    Parameters
    ----------
    cvar_data : cvar_optimizer.CVaR_Data
        Scenario container returned by :pyfunc:`generate_CVaR_data`.
    portfolio : Portfolio
        Instance with populated ``weights`` on the same tickers order.
    confidence_level : float
        Tail probability for CVaR, e.g. 0.95.

    Returns
    -------
    dict
        ``{'portfolio', 'return', 'variance', 'CVaR'}``.
    """
    portfolio_expected_return = portfolio.calculate_portfolio_expected_return(cvar_data.mean)
    portfolio_variance = portfolio.calculate_portfolio_variance(cvar_data.covariance)
    portfolio_CVaR = compute_CVaR(cvar_data, portfolio.weights, confidence_level)

    return {'portfolio': portfolio, 'return': portfolio_expected_return, 'variance': portfolio_variance, 'CVaR': portfolio_CVaR}

def compute_CVaR(cvar_data, weights, confidence_level): 
    """
    Vanilla Monte-Carlo CVaR given pre-generated scenarios.

    Parameters
    ----------
    cvar_data : cvar_optimizer.CVaR_Data
    weights : ndarray of shape (n_assets,)
        Must sum to 1 including cash weight if any.
    confidence_level : float in (0, 1)

    Returns
    -------
    float
        *Positive* CVaR (absolute expected shortfall).
    """
    portfolio_returns = cvar_data.R.T @ weights
    VaR = np.percentile(portfolio_returns, (1-confidence_level)*100)
    tail_loss = portfolio_returns[portfolio_returns <= VaR]
    CVaR = np.abs(np.mean(tail_loss))

    return CVaR

def evaluate_single_asset_portfolios(cvar_problem):
    """
    Enumerate **n** portfolios, each fully invested (``w_max``) in a single
    asset and the remainder in cash.

    Parameters
    ----------
    cvar_problem : cvar_optimizer.CVaR
        Already initialised optimisation object.

    Returns
    -------
    pandas.DataFrame
        Index = tickers, columns = ['portfolio', 'return', 'variance', 'CVaR'].
    """
    single_asset_portfolio_performance = pd.DataFrame([], dtype = np.float64, index = cvar_problem.tickers,\
                                                      columns = ['portfolio', 'return', 'variance', 'CVaR'])

    for idx, ticker in enumerate(cvar_problem.tickers):
        portfolio_name = ticker + '_single_portfolio'
        weights_dict = {ticker: cvar_problem.params.w_max}
        cash = 1 - cvar_problem.params.w_max
        
        portfolio = Portfolio(tickers=cvar_problem.tickers, time_range = cvar_problem.regime_range)
        portfolio.portfolio_from_dict(portfolio_name, weights_dict, cash)
        
        portfolio_performance = evaluate_portfolio_performance(cvar_problem.data, portfolio, cvar_problem.params.confidence)
        single_asset_portfolio_performance.loc[ticker] = portfolio_performance
    
    return single_asset_portfolio_performance

def generate_user_input_portfolios(portfolios_dict, returns_dict, existing_portfolios = []):
    """
    Convert user-supplied weight dictionaries → Portfolio objects.

    Parameters
    ----------
    portfolios_dict : dict
        ``{portfolio_name: (weight_dict, cash)}``.
    returns_dict : dict
        Need only ``'tickers'`` and ``'regime'`` fields to instantiate
        :class:`Portfolio`.
    existing_portfolios : list[Portfolio] or pandas.DataFrame, default None
        Previously created objects to append to.

    Returns
    -------
    list[Portfolio]
        *New list* containing all portfolios (old + new).

    Raises
    ------
    ValueError
        If ``existing_portfolios`` is neither list nor DataFrame.
    """
    if isinstance(existing_portfolios, pd.DataFrame):
        if not existing_portfolios.empty:
            existing_portfolios = existing_portfolios['portfolio'].tolist()
        else: 
            existing_portfolios = []
            
    elif isinstance(existing_portfolios, list):
        pass
    else: 
        raise ValueError('Existing portfolios type not supported - it has to be a list of Portfolios or a DataFrame with portfolio performance.')
        
    for portfolio_name, portfolio_tuple in portfolios_dict.items():
        
        weights_dict, cash = portfolio_tuple
        portfolio = Portfolio(tickers=returns_dict['tickers'], time_range = returns_dict['regime']['range'])
        portfolio.portfolio_from_dict(portfolio_name, weights_dict, cash)
        
        existing_portfolios.append(portfolio)
    
    return existing_portfolios

def evaluate_user_input_portfolios(cvar_problem, portfolios_dict, returns_dict,
                                   custom_portfolios=pd.DataFrame([], columns = ['portfolio_name', 'portfolio', 'return', 'variance', 'CVaR'])):
    """
    Attach performance metrics to arbitrary user-defined portfolios.

    Parameters
    ----------
    cvar_problem : cvar_optimizer.CVaR
        Provides scenario data and solver parameters.
    portfolios_dict : dict
        Forwarded to :pyfunc:`generate_user_input_portfolios`.
    returns_dict : dict
        Pass-through from earlier pipeline step.
    custom_portfolios : pandas.DataFrame, optional
        Existing records.  Rows with duplicate ``'portfolio_name'`` are
        ignored (a warning is printed).

    Returns
    -------
    pandas.DataFrame
        ``custom_portfolios`` augmented with new rows.
    """
    existing_portfolios = generate_user_input_portfolios(portfolios_dict, returns_dict, custom_portfolios)
    
    for portfolio in existing_portfolios:
        portfolio_performance = evaluate_portfolio_performance(cvar_problem.data, portfolio, cvar_problem.params.confidence)
        portfolio_performance['portfolio_name'] = portfolio.name
        
        portfolio_dataframe = pd.Series(portfolio_performance, index = custom_portfolios.columns).to_frame().T
        if custom_portfolios.shape[0] > 0:
            if portfolio.name not in custom_portfolios['portfolio_name'].values:
                custom_portfolios = pd.concat([custom_portfolios, portfolio_dataframe], ignore_index = False)
            else:
                    print(f"{portfolio_dataframe['portfolio_name'].values} already exists or please change to a different portfolio name.")
        else: 
            custom_portfolios = portfolio_dataframe
            
    custom_portfolios.reset_index(drop = True, inplace = True)
    
    return custom_portfolios

def generate_efficient_frontier(returns_dict, cvar_params, \
                            device = 'CPU', gpu_settings = None, cpu_settings = {'verbose': False},\
                            folder_name = None, key_portfolios = 'default', opt_result_verbose = False, custom_portfolios_dict = {},\
                            title = None, EF_result_csv_name = None, \
                            EF_plot_png_name = None, show_plot = True, min_risk_aversion = -2, max_risk_aversion = 0.5, ra_num = 5):
    
    """
    Compute and (optionally) plot a CVaR-based efficient frontier.

    The optimisation is re-solved for a log-spaced grid of risk-aversion
    coefficients ``λ`` (``cvar_params.risk_aversion``).

    Parameters
    ----------
    returns_dict : dict
        Output of :pyfunc:`calculate_returns`.
    cvar_params : CVaR_Parameters
        Mutable – the function overwrites ``risk_aversion`` repeatedly.
    device : {'CPU', 'GPU'}, default 'CPU'
        Solver backend.  JSON files are created only when
        ``device == 'GPU'`` **and** ``folder_name`` is supplied.
    gpu_settings, cpu_settings : dict or None
        Tunables forwarded to the solver.
    folder_name : str or None
        Destination for cuOpt problem files (GPU only).
    key_portfolios : dict or 'default'
        ``{portfolio_name: marker}`` to highlight in the plot.
    opt_result_verbose : bool, default False
        Print full optimisation result from each run.
    custom_portfolios_dict : dict, default {}
        Extra portfolios to annotate on the plot.
    title : str or None
        Figure title.  Generated automatically if None.
    EF_result_csv_name : str or None
        Persist the dataframe to disk.
    EF_plot_png_name : str or None
        Persist the plot as PNG.
    show_plot : bool, default True
        Display figure inline (might block notebooks).
    min_risk_aversion, max_risk_aversion : float
        Inclusive boundaries of log-scale grid.
    ra_num : int
        Number of grid points.

    Returns
    -------
    pandas.DataFrame
        Solver summary over the full λ-grid (return, CVaR, Sharpe, …).
    """
        
    device = device.upper()
        
    if key_portfolios == 'default': #default key portfolios
        key_portfolios = dict(zip(['Min_Var', 'Max_Sharpe', 'Max_Return'],['*', 'o', 'D']))
            
    columns = ['regime', "solve time", "return", 'CVaR', "obj", "optimal portfolio", "risk"]
    result_dataframe = pd.DataFrame([], columns=columns)
        
    # Initialise optimisation problem once, then tweak λ
    cvar_problem = cvar_optimizer.CVaR(returns_dict = returns_dict, cvar_params = cvar_params)
        
    if custom_portfolios_dict:
        custom_portfolios = evaluate_user_input_portfolios(cvar_problem, custom_portfolios_dict, returns_dict)
            
    # Single-asset portfolios for scatter overlay
    single_asset_portfolios = evaluate_single_asset_portfolios(cvar_problem)
        
    # Build geometric sequence of risk-aversion values
    risk_aversion_list = np.logspace(start = min_risk_aversion, stop = max_risk_aversion, num = ra_num)[::-1].round(5)

    for ra_value in risk_aversion_list: 
        cvar_problem.params.update_risk_aversion(ra_value)
        cvar_problem._set_up() #re-set-up the problem
            
        if device == 'GPU' and folder_name is not None:
            file_name = returns_dict['regime']['name'] + '-num_scen'\
                                + str(cvar_params.num_scen) + '-risk_aversion' + str(round(ra_value,2))
                
            to_file = (folder_name, file_name)
                
        else:
            to_file = None

            
        result_row, portfolio = cvar_problem.solve_optimization_problem(device = device, gpu_settings = gpu_settings, cpu_settings = cpu_settings, to_file = to_file, print_result = False)
            
        result_row['risk'] = portfolio.calculate_portfolio_variance(cvar_problem.data.covariance)
        result_row['optimal portfolio'] = portfolio.print_clean()
            
        result_dataframe = pd.concat([result_dataframe, result_row.to_frame().T], ignore_index = True)

    result_dataframe['sharpe'] = result_dataframe['return'] / result_dataframe['CVaR']
        
    if EF_result_csv_name: 
        result_dataframe.to_csv(EF_result_csv_name)
        
    # Delegate plotting to utils
    utils.plot_efficient_frontier('CVaR', result_dataframe, single_asset_portfolios, custom_portfolios, key_portfolios, opt_result_verbose, title, show_plot, EF_plot_png_name)
    return result_dataframe
