'''
SPDX-FileCopyrightText: Copyright (c) 2021-2025 NVIDIA CORPORATION &
AFFILIATES. All rights reserved. SPDX-License-Identifier:
LicenseRef-NvidiaProprietary

NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
property and proprietary rights in and to this material, related
documentation and any modifications thereto. Any use, reproduction,
disclosure or distribution of this material and related documentation
without an express license agreement from NVIDIA CORPORATION or
its affiliates is strictly prohibited.
'''

from dataclasses import dataclass
import datetime as dt
import os
import json

import numpy as np
import pandas as pd
import math
import scipy
from scipy.stats import norm
from scipy.sparse import csr_matrix
from sklearn.neighbors import KernelDensity
import cvxpy as cp

import matplotlib.pyplot as plt
import seaborn as sns


class BaseOptimizer:
    """
    Base class for portfolio optimization routines.

    This class sets up the core data structures and parameters needed
    for various risk-based optimizers (e.g., CVaR, variance minimization).

    Parameters
    ----------
    returns_dict : dict
        Dictionary containing asset return information. Must include:
        - 'tickers': list of asset identifiers.
        May include additional raw return series or metadata.
    weights_previous : array-like of shape (n_assets,), optional
        Weights of the existing portfolio. If None or empty, defaults to
        an equally-weighted portfolio.
    risk_measure : str
        Risk measure to be used for optimization. Supported values include:
        - 'CVaR'
        - 'variance'

    Attributes
    ----------
    returns_dict : dict
        The input dictionary of return series and metadata.
    tickers : list of str
        List of asset tickers extracted from `returns_dict`.
    n_assets : int
        Number of assets (length of `tickers`).
    risk_measure : str
        Selected risk measure for optimization.
    weights_previous : np.ndarray of shape (n_assets,)
        Current portfolio weights; used for turnover or transaction cost calculations.
    weights : np.ndarray of shape (n_assets,)
        New portfolio weights to be computed by optimizer (set via `set_weights`).

    Public Methods
    --------------
    set_weights(weights_dict)
        Create or update `self.weights` from a mapping of tickers to weights.
    clean_weights()
        Round weights to a reasonable precision and zero out near-zero values.
    calculate_returns()
        Compute mean vector and covariance matrix of log returns,
        assuming a multivariate normal distribution.
    """

    def __init__(self, returns_dict, weights_previous, risk_measure):
        """
        Initialize core data for portfolio optimization.

        Sets up asset universe, previous weights, and risk measure.

        Parameters
        ----------
        returns_dict : dict
            Must include key 'tickers' mapping to a list of asset tickers.
        weights_previous : array-like of shape (n_assets,), optional
            Existing portfolio weights. If None or empty, uniform weights
            are created (equal allocation).
        risk_measure : str, default='variance'
            Risk measure to optimize. Examples: 'variance', 'CVaR'.
        """
        # Store the raw returns dictionary and extract tickers
        self.returns_dict = returns_dict
        self.tickers = returns_dict['tickers']
        
        # Number of assets in the portfolio
        self.n_assets = len(self.tickers)

        # Chosen risk metric for optimization algorithms
        self.risk_measure = risk_measure

        # Initialize or validate existing portfolio weights.
        # If no previous weights provided, assume equal-weighted portfolio.
        if not weights_previous:
            # Create uniform weights summing to 1
            self.weights_previous = np.ones(self.n_assets) / self.n_assets
        else: 
            # Use the provided weights array directly
            self.weights_previous = weights_previous



    


