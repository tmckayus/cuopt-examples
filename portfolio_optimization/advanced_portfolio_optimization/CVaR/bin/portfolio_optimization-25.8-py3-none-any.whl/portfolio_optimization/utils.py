'''
SPDX-FileCopyrightText: Copyright (c) 2021-2025 NVIDIA CORPORATION &
AFFILIATES. All rights reserved. SPDX-License-Identifier:
LicenseRef-NvidiaProprietary

NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
property and proprietary rights in and to this material, related
documentation and any modifications thereto. Any use, reproduction,
disclosure or distribution of this material and related documentation
without an express license agreement from NVIDIA CORPORATION or
its affiliates is strictly prohibited.
'''

import matplotlib.pyplot as plt
import seaborn as sns
from dataclasses import dataclass
import datetime as dt
import os
import json

import numpy as np
import pandas as pd

def customize_dataset(filepath):
    """
    Interactively build a *user-defined* data subset and persist it on disk.

    The routine performs three steps:

    1. Reads the full price/returns data set from **`filepath`**.
    2. Prompts the user to select a subset of columns (*tickers*).
    3. Saves the reduced data set in the same directory, naming it
       ``User_custom_data_set.csv``.

    Parameters
    ----------
    filepath : str or os.PathLike
        Absolute or relative path to the input file.  Supported formats are
        identical to those handled by :func:`get_input_data`.

    Returns
    -------
    str
        Full path pointing to the newly written CSV file.

    Notes
    -----
    `input()` is used for ticker selection, which makes the function
    unsuitable for non-interactive environments.
    """
    # Extract folder part
    directory_path = os.path.dirname(filepath)

    complete_data = get_input_data(filepath)
    available_tickers = set(complete_data.columns)

    # Ask the user to input tickers (comma-separated)
    print(f'Available tickers to select from: {available_tickers}' )
    user_input = input("Enter the tickers you want, separated by commas: ")
    custom_dataset_name = "User_custom_data_set"

    # Normalise the user input: strip whitespace, remove stray quotes, upper-case
    selected_tickers = [
        ticker.strip().strip("'").upper() if "'" in ticker else ticker.strip().upper()
        for ticker in user_input.split(",")
    ]

    # Sanity check ---------------------------------------------------------------
    invalid_tickers = [ticker for ticker in selected_tickers if ticker not in available_tickers]

    if invalid_tickers:
        print(f"Error: The following tickers are not available in the dataset: {', '.join(invalid_tickers)}")
    else:
        print(f"Selected tickers: {', '.join(selected_tickers)}")
        
    # Extract the relevant data
    selected_data = complete_data[selected_tickers]

    selected_data_path = f'{directory_path}/{custom_dataset_name}.csv'
    selected_data.to_csv(selected_data_path)

    return selected_data_path

def get_input_data(filepath):
    """
    Generic loader utility that infers the correct pandas reader from the
    filename extension.

    Parameters
    ----------
    filepath : str or os.PathLike
        Path to the data file.  Supported extensions (case-insensitive):

        ==========  Reader used
        ``.csv``    :func:`pandas.read_csv`
        ``.parquet``:func:`pandas.read_parquet`
        ``.xls[x]`` :func:`pandas.read_excel`
        ``.json``   :func:`pandas.read_json`

    Returns
    -------
    pandas.DataFrame
        Data frame indexed exactly as stored on disk, with *columns that
        contain only ``NaN`` values dropped*.

    Raises
    ------
    ValueError
        If the extension is not among the supported set.
    """
    _, file_extension = os.path.splitext(filepath)
    file_extension = file_extension.lower()
    
    if file_extension == '.csv':
        df = pd.read_csv(filepath, index_col = 0)
    elif file_extension == '.parquet':
        df = pd.read_parquet(filepath)
    elif file_extension in ['.xls', '.xlsx']:
        df = pd.read_excel(filepath)
    elif file_extension == '.json':
        df = pd.read_json(filepath)
    else:
        raise ValueError(f"Unsupported file extension: {file_extension}")
    df = df.dropna(axis = 1)
    return df   

def calculate_returns(input_file_name, regime_dict, return_type = 'LOG'):
    """
    Slice a price series into a *regime*, convert to returns, and compute
    summary statistics.

    Parameters
    ----------
    input_file_name : str
        Path pointing to the *price* data file.
    regime_dict : dict
        Dictionary describing the subsample to extract.  Must contain a
        ``'range'`` key mapping to ``(start, end)`` — both strings or
        pandas-parsable date-like objects.  Use ``None`` to keep the full
        range.
    return_type : {'LOG', 'PNL'}, default 'LOG'
        • ``'LOG'`` – natural log-returns `ln(P_t / P_{t-1})`
        • ``'PNL'`` – raw price differences (a.k.a. *PnL*).

    Returns
    -------
    dict
        Keys
        ----
        ``'return_type'`` : literal echo of the `return_type` argument  
        ``'returns'``     : *pandas.DataFrame* with the computed returns  
        ``'regime'``      : the original `regime_dict` for traceability  
        ``'dates'``       : pandas.Index of observation dates  
        ``'mean'``        : *numpy.ndarray* (`float64`, shape = [n_assets])  
        ``'covariance'``  : *numpy.ndarray* (shape = [n_assets, n_assets])  
        ``'tickers'``     : list of column names in the input file

    Raises
    ------
    NotImplementedError
        If an unsupported `return_type` is supplied.
    """
    return_type = return_type.upper()
        
    input_data = get_input_data(input_file_name)
    regime_range = regime_dict['range']
    if regime_range is None: 
        returns_data = input_data
    else:
        start, end = regime_range
        returns_data = input_data.loc[start:end]
    returns_data = returns_data.dropna(axis = 1)
        
    if return_type == 'LOG':
        returns_dataframe = calculate_log_returns(returns_data)
        # Retrieve the mean and covariance of log returns
        returns = returns_dataframe.to_numpy()
        m = np.mean(returns, axis = 0)
        cov = np.cov(returns.transpose())
            
    elif return_type == 'PNL': 
        returns_dataframe = returns_data
        # Retrieve the mean and covariance of returns
        returns = returns_dataframe.to_numpy()
        m = np.mean(returns, axis = 0)
        covariance = np.cov(returns.transpose())
            
    else: 
        raise NotImplementedError("Invalid return type!")
            
    dates = returns_dataframe.index
    returns_dict = {'return_type': return_type, 'returns': returns_dataframe, 'regime': regime_dict, 'dates': dates,
                'mean': m, 'covariance': cov, 'tickers': list(input_data.columns)}
        
    return returns_dict

def calculate_log_returns(price_data): 
    """
    Vectorised helper for *daily* log-return computation.

    Parameters
    ----------
    price_data : pandas.DataFrame
        Price observations, column-wise by asset.

    Returns
    -------
    pandas.DataFrame
        Log returns where
        ``R_t = ln(P_t) − ln(P_{t−1})``, with
        • rows containing only NaNs dropped, and  
        • residual NaNs (e.g. due to IPO dates) filled with 0.
    """
    returns_dataframe = price_data.apply(np.log) - price_data.shift(1).apply(np.log)
    returns_dataframe = returns_dataframe.dropna(how = 'all')
    returns_dataframe = returns_dataframe.fillna(0)
    
    return returns_dataframe

def create_save_path(folder, save_name):
    """
    Ensure *folder* exists and join it with *save_name*.

    Parameters
    ----------
    folder : str or os.PathLike
        Target directory (created if absent).
    save_name : str
        Filename to append.

    Returns
    -------
    str
        Concatenated path ``folder/save_name``.
    """
    os.makedirs(folder, exist_ok=True)  # Create the directory if it doesn't exist
    save_path = os.path.join(folder, save_name)
    
    return save_path

def plot_efficient_frontier(risk_measure, result_dataframe, single_asset_portfolio, custom_portfolios, key_portfolios,\
                            verbose = False, title = None, show_plot = True, EF_plot_png_name = None): 
    """
    Visualise an efficient frontier augmented with *special* and *custom* portfolios.

    Parameters
    ----------
    risk_measure : str
        Column in *result_dataframe* to plot on the x-axis (e.g. ``'risk'``,
        ``'variance'``, ``'CVaR'``).
    result_dataframe : pandas.DataFrame
        Optimiser output—one row per risk-aversion level, containing at
        minimum ``risk_measure`` and a ``'return'`` column.
    single_asset_portfolio : pandas.DataFrame
        Performance metrics for *pure* single-stock portfolios.  Must
        include the same ``risk_measure`` and ``'return'`` columns.
    custom_portfolios : pandas.DataFrame
        User-defined portfolios (optional).  Requires ``risk_measure``,
        ``'return'``, and ``'portfolio_name'`` columns.
    key_portfolios : dict[str, str]
        Mapping ``name → marker`` indicating which optimiser rows to
        emphasise and which matplotlib marker to use (e.g. ``'min_var':'X'``).
        Internally resolved via :func:`get_portfolio`.
    verbose : bool, default False
        If *True*, annotate *key* portfolios with full asset weights.
    title : str or None, default None
        Custom plot title; defaults to
        “Efficient Frontier with *n* Stocks”.
    show_plot : bool, default True
        Whether to call :func:`matplotlib.pyplot.show`.
    EF_plot_png_name : str or None, default None
        If supplied, the figure is saved under this path.

    Notes
    -----
    • Seaborn styles and palettes are set locally.  Callers that rely on
      global styling should re-apply their preferences afterwards.  
    • The function assumes a screen DPI of approximately 100 for sizing.
    """
    sns.set(rc={"figure.dpi":100, 'savefig.dpi':300})
    sns.set_palette(palette='Blues_d')
    sns.set_style('white')
    plt.figure(figsize=(10, 7))

    if key_portfolios is not None:
        # Plot the markers for the key portfolios
        example_portfolio = pd.DataFrame({}, columns = result_dataframe.columns)
        for portfolio_name, marker in key_portfolios.items(): 
            portfolio_idx = get_portfolio(result_dataframe, portfolio_name)
            example_portfolio = pd.concat([example_portfolio, result_dataframe.iloc[portfolio_idx].to_frame().T])
            sns.scatterplot(data = result_dataframe.iloc[portfolio_idx].to_frame().T, 
                            x = risk_measure, y = 'return', 
                            marker = marker, s= 100, color = 'darkorange', label = portfolio_name, legend = True, zorder = 2)
        example_portfolio = example_portfolio.reset_index()
        
        if verbose:
            # Create the annotation box for the key portfolios
            annotated_points = []
            annotation_list = []

            offset_list = [(-15,-150), (20,-70), (-15,-70)]

            for row_idx, row in example_portfolio.iterrows(): 
                point = (row.loc[risk_measure], row.loc['return'])

                annotation = ''
                weights_dict, cash = row['optimal portfolio']
                for ticker, weight in weights_dict.items():
                    if weight > 5e-2 or weight < -5e-2:
                        annotation += ticker + f': {weight: .2f}\n'

                annotation += f'cash: {cash: .2f}'
                annotation = annotation.rstrip('\n')

                plt.annotate(annotation, 
                             xy=point, 
                             ha = 'left',
                             xytext= offset_list[row_idx],
                             textcoords='offset points',
                             fontsize=10,
                             bbox=dict(boxstyle="round,pad=0.4", facecolor="#e8dff5", edgecolor = 'black'),
                             arrowprops=dict(arrowstyle="->", connectionstyle="arc3,rad=0.3", color = 'black'))

    # Create line for efficient frontier
    sns.lineplot(data = result_dataframe, x = risk_measure, y = 'return', linewidth = 3, zorder = 1,\
                 label = 'Optimal Portfolios')
    plt.legend()
    
    custom_portfolio_markers = ['s', '^', 'v', '<', '>', 'p', 'h']
    if not custom_portfolios.empty:
        for i in range(0, len(custom_portfolios)):
            portfolio = custom_portfolios.iloc[i]
            annotation = portfolio['portfolio_name']
            plt.scatter(x = portfolio[risk_measure], y =portfolio['return'],\
                            marker = custom_portfolio_markers[i],\
                            color = '.2', zorder = 4, label = annotation)
    plt.legend()
    
    # Scatter plot the single asset portfolios
    sns.scatterplot(data = single_asset_portfolio, x = risk_measure, y = 'return', 
                    hue = 'variance', size = 'variance', 
                    palette='icefire', legend = False, zorder = 3)
    
    for i in range(0, len(single_asset_portfolio)):
        plt.annotate(f'{single_asset_portfolio.index[i]}', 
                     (single_asset_portfolio[risk_measure][i], single_asset_portfolio['return'][i]), 
                     textcoords="offset points", 
                     xytext=(2,3) if i %2 == 0 else (-4,-6), fontsize = 6, ha='center')
    if not title: 
        plt.title(f'Efficient Frontier with {len(single_asset_portfolio)} Stocks' )
    else: 
        plt.title(title)
    if EF_plot_png_name:
        
        plt.savefig(EF_plot_png_name)
    if show_plot:
        plt.show()


def get_portfolio(result, portfolio_name):
    """
    Helper to *locate* a portfolio inside `result` based on a human-readable identifier.

    Parameters
    ----------
    result : pandas.DataFrame
        Data frame with at least the columns ``'risk'``, ``'return'`` and
        ``'sharpe'`` (case-sensitive).
    portfolio_name : {'min_var', 'max_sharpe', 'max_return'}
        Keyword specifying the desired point on the efficient frontier.

    Returns
    -------
    int
        Row index of the matching portfolio in *result*.

    Raises
    ------
    ValueError
        For unrecognised `portfolio_name` values.
    """
    portfolio_name = portfolio_name.lower()
    if portfolio_name == 'min_var': 
        min_value = result['risk'].min()
        idx = result[result['risk'] == min_value].index[0]
    elif portfolio_name == 'max_sharpe': 
        max_sharpe = result['sharpe'].max()
        idx = result[result['sharpe'] == max_sharpe].index[0]
    elif portfolio_name == 'max_return':
        max_return = result['return'].max()
        idx = result[result['return'] == max_return].index[-1]
    else: 
        raise ValueError('portfolio_name should be a string (e.g. min_var, max_sharpe, max_return)')

    return idx


def portfolio_plot_with_backtest(portfolio, backtester, cut_off_date, backtest_plot_title): 
    """
    Convenience wrapper that stitches together a *static* weight pie chart
    and a *back-test* performance plot side-by-side.

    Parameters
    ----------
    portfolio : object
        Instance exposing a ``plot_portfolio(ax=...)`` method that draws
        e.g. a weight breakdown.
    backtester : object
        Instance exposing a ``backtest_against_benchmarks`` method with the
        signature
        ``backtest_against_benchmarks(plot_returns=True, ax=..., cut_off_date=..., title=...)``.
    cut_off_date : str or compatible
        Forwarded unmodified to the backtester—typically the start date of
        the out-of-sample period.
    backtest_plot_title : str
        Title string passed verbatim to the backtester.
    """
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 5))
    
    ax1 = portfolio.plot_portfolio(ax=ax1)

    _, ax2 = backtester.backtest_against_benchmarks(plot_returns = True, ax = ax2,\
                                                 cut_off_date = cut_off_date, title = backtest_plot_title)
    
    plt.tight_layout()
    plt.show()


