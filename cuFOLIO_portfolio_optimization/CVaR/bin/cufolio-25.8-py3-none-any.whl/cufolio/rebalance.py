'''
SPDX-FileCopyrightText: Copyright (c) 2021-2025 NVIDIA CORPORATION &
AFFILIATES. All rights reserved. SPDX-License-Identifier:
LicenseRef-NvidiaProprietary

NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
property and proprietary rights in and to this material, related
documentation and any modifications thereto. Any use, reproduction,
disclosure or distribution of this material and related documentation
without an express license agreement from NVIDIA CORPORATION or
its affiliates is strictly prohibited.
'''

import os
import json

from . import cvar_utils, utils, backtest, portfolio
from . import cvar_optimizer

# from src import cvar_optimizer as cvar_optimizer

import cvxpy as cp
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

class rebalance_portfolio:
    """
    Incrementally re-optimises (a.k.a. *re-balances*) a portfolio over a
    forward-testing horizon under user-supplied criteria such as cumulative
    percent change, drift, or draw-down.

    The class will:

    1. Read raw price series from ``dataset_directory``.
    2. Convert them into the desired **return** representation
       (log or arithmetic).
    3. Walk through trading dates in ``look_forward_window`` steps; at each
       step it runs a CVaR optimisation *iff* the chosen
       ``re_optimize_criteria`` is breached.
    4. Optionally run the **same** back-test without re-optimisation so that
       both tracks can be plotted side-by-side.

    Attributes
    ----------
    dataset_directory : str
        CSV file path that contains raw price levels
        (rows: dates, columns: tickers).
    trading_start, trading_end : pandas.Timestamp
        Inclusive begin / end points for the re-balancing exercise.
    look_forward_window : int
        Number of trading *days* for each out-of-sample back-test step.
    look_back_window : int
        Number of trading *days* used to estimate inputs for the optimiser.
    cvar_params : CVaR_Parameters
        Encapsulates tail-risk parameters (α, long/short bounds, etc.).
    gpu_configs : dict
        Dictionary with solver settings understood by
        :class:`cvar_optimizer.CVaR`.
    return_type : {'LOG', 'PNL'}
        Choice of return metric.  Currently only log-returns are implemented.
    re_optimize_criteria : dict
        Example::

            {
              'type': 'pct_change',
              'threshold': -0.05
            }

        ``type`` ∈ {'pct_change', 'drift_from_optimal', 'max_drawdown',
        'no_re_optimize'}.  ``threshold`` is interpreted by the
        corresponding checker.
    print_opt_result : bool
        Forwarded verbatim to ``CVaR.solve_optimization_problem``.
    """
    def __init__(self, dataset_directory, trading_start, trading_end, look_forward_window,
                 look_back_window, cvar_params, gpu_configs, re_optimize_criteria, return_type, print_opt_result):
        self.dataset_directory = dataset_directory
        self.trading_start = pd.to_datetime(trading_start)
        self.trading_end = pd.to_datetime(trading_end)
        
        self.look_forward_window = look_forward_window
        self.look_back_window = look_back_window
        
        self.cvar_params = cvar_params
        self.gpu_configs = gpu_configs
        self.return_type = return_type
        
        self.re_optimize_criteria = re_optimize_criteria
        self.re_optimize_type = re_optimize_criteria['type'].lower()
        self.re_optimize_threshold = re_optimize_criteria['threshold']
        self.print_opt_result = print_opt_result

        # Compute returns once up-front (shared by all back-tests)
        self._calculate_returns()
        # Slice the date index only over the trading horizon
        self.dates_range = self.returns_data.loc[trading_start:trading_end].index
        # Reference run without any re-balancing for plotting & comparison
        self.no_reoptimize_results = self._get_no_reoptimize_results()
        
        
    def _calculate_returns(self):
        """
        Load raw price data and derive the **returns_data** attribute.

        Raises
        ------
        AssertionError
            If the requested look-back window would require data that predates
            the beginning of the price file.
        """
        self.price_data = pd.read_csv(self.dataset_directory, index_col = 0, parse_dates = True)

        if self.return_type == 'LOG':
            self.returns_data = utils.calculate_log_returns(self.price_data)

        # Ensure we have enough historical data for the first optimization
        price_data_start = self.trading_start - pd.Timedelta(days = self.look_back_window)
        assert price_data_start >= self.returns_data.index[0], "Invalid start date - choose a later date!"
        
    def re_optimize(self, transaction_cost_factor = 0, plot_results = False, existing_portfolio = None, run_re_optimize = True):
        """
        Main entry point: execute the rolling back-test.

        Parameters
        ----------
        transaction_cost_factor : float, default 0
            Slippage applied per unit turnover.
        plot_results : bool, default False
            If ``True`` produce a Matplotlib figure at the end.
        existing_portfolio : portfolio.Portfolio or None
            Seed starting holdings.  ``None`` → optimise from scratch.
        run_re_optimize : bool, default True
            ``False`` forces a *benchmark* pass without any re-optimisation.

        Returns
        -------
        tuple
            (``results_dataframe``, ``re_optimize_dates``)

            * ``results_dataframe`` : pandas.DataFrame  
              Row index = back-test anchor dates.  Columns:

              - re-optimisation criterion value
              - 're_optimized' (bool)
              - 'optimal_portfolio' (Portfolio object)
              - 'portfolio_value' (float)

            * ``re_optimize_dates`` : list[datetime]
              Time-stamps where a new optimisation was triggered.
        """
        if run_re_optimize:
            print("*****Testing Re-Optimize*****")
        result = 0 
        re_optimize_flag = False
        portfolio_value = 1

        # Will be filled after first optimization
        current_portfolio = None

        results_dataframe = pd.DataFrame(columns = [self.re_optimize_type, 're_optimized', 'portfolio_value'])
        no_re_optimize_results = pd.DataFrame(columns = ['portfolio_value'])
        
        backtest_idx = 0
        backtest_dates_list = []
        

        re_optimize_dates = []

        # ───────────────────────────────────────────────────────────────
        # Walk-forward loop: one iteration per *step* not per *day*
        # ───────────────────────────────────────────────────────────────
        while backtest_idx <= len(self.dates_range) - 1:
            backtest_date = self.dates_range[backtest_idx]

            # Record state before any decision is made
            results_dataframe.loc[backtest_date, self.re_optimize_type] = result
            results_dataframe.loc[backtest_date, 're_optimized'] = re_optimize_flag
            results_dataframe.loc[backtest_date, 'optimal_portfolio'] = current_portfolio
            results_dataframe.loc[backtest_date, 'portfolio_value'] = portfolio_value
            
            existing_portfolio = current_portfolio
            
            # ─────────────────────────────────────────────────────────
            # 1. OPTIMIZE if needed
            # ─────────────────────────────────────────────────────────
            if backtest_idx == 0 or re_optimize_flag:
                optimize_start = backtest_date - pd.Timedelta(days = self.look_back_window)
                optimize_regime = {'name': 're-optimize', 'range':(optimize_start.strftime('%Y-%m-%d'), backtest_date.strftime('%Y-%m-%d'))}
    #             print(f'Re-Optimize on {optimize_start} -> {backtest_date}')
                optimize_returns_dict = cvar_utils.calculate_returns(self.dataset_directory, optimize_regime, self.return_type, self.cvar_params)

                re_optimize_problem = cvar_optimizer.CVaR(returns_dict = optimize_returns_dict, \
                                                          cvar_params = self.cvar_params, existing_portfolio = existing_portfolio)

                _, current_portfolio = re_optimize_problem.solve_optimization_problem(device = 'GPU', gpu_settings = self.gpu_configs['settings'], print_result = self.print_opt_result)
                re_optimize_dates.append(backtest_date)

            # ─────────────────────────────────────────────────────────
            # 2. BACKTEST forward (*out-of-sample*) window
            # ─────────────────────────────────────────────────────────
            backtest_start = backtest_date.strftime('%Y-%m-%d')
            backtest_end = backtest_date + pd.Timedelta(days = self.look_forward_window) 
            backtest_end = backtest_end.strftime('%Y-%m-%d')
            backtest_regime = {'name': 'backtest', 'range': (backtest_start, backtest_end)}
    #         print(f'Backtest on {backtest_date} to {backtest_end}')

            test_returns_dict = utils.calculate_returns(self.dataset_directory, backtest_regime, self.return_type)

            # Run backtest
            backtester = backtest.portfolio_backtester(current_portfolio, test_returns_dict, benchmark_portfolios = None)
            backtest_result = backtester.backtest_single_portfolio(current_portfolio)

            # Update *cumulative* portfolio value
            portfolio_value_pct_change = self._calculate_pct_change(backtest_result)
            transaction_cost = self._calculate_transaction_cost(current_portfolio, existing_portfolio, transaction_cost_factor)
            portfolio_value = portfolio_value * (1 + portfolio_value_pct_change - transaction_cost)
            
            # ─────────────────────────────────────────────────────────
            # 3. Decide whether to re-optimize *on next loop*
            # ─────────────────────────────────────────────────────────
            if run_re_optimize:
                if self.re_optimize_type == 'pct_change':
                    result, re_optimize_flag = self._check_pct_change(portfolio_value_pct_change, backtest_result, results_dataframe)
                elif self.re_optimize_type == 'drift_from_optimal':
                    result,re_optimize_flag = self._check_drift_from_optimal(current_portfolio, backtest_idx) 

                elif self.re_optimize_type == 'max_drawdown': 
                    result = backtest_result['max drawdown'].values[0]
                    re_optimize_flag = self._check_max_drawdown(result)

                elif self.re_optimize_type == 'no_re_optimize':
                    re_optimize_flag = False
                    result = None
            
            # Advance index by *window* not by day    
            backtest_idx += self.look_forward_window
            backtest_dates_list.append(backtest_date)
        
        if plot_results: 
            self.plot_results(results_dataframe, re_optimize_dates)
            
        return results_dataframe, re_optimize_dates
    
    def _calculate_pct_change(self, backtest_result):
        """
        Compute final period-over-period percentage change from an individual
        back-test run.

        Parameters
        ----------
        backtest_result : pandas.DataFrame
            Output of
            :meth:`backtest.portfolio_backtester.backtest_single_portfolio`.

        Returns
        -------
        float
            Percent change expressed as decimal (e.g. 0.04 == +4 %).
        """
        cumulative_returns = backtest_result['cumulative returns'][0]
        pct_change = cumulative_returns[-1] / cumulative_returns[0] - 1 #percent change
        
        return pct_change
    
    def _calculate_transaction_cost(self, current_portfolio, existing_portfolio, transaction_cost_factor):
        """
        Naïve linear cost model: *turnover* × *factor*.

        Currently turnover evaluates to **zero** because it is the absolute
        difference of the **same** weight vector; left in place to signal
        where a realistic model should live.

        Returns
        -------
        float
            Cost deducted from next portfolio-value multiplication.
        """
        turnover = np.sum(np.abs(current_portfolio.weights - current_portfolio.weights))
        return turnover * transaction_cost_factor
    
    def _check_pct_change(self, pct_change, backtest_result, results_dataframe):
        """
        Decide whether *pct_change* breaches the cumulative threshold.

        The cumulative metric adds together consecutive negative observations
        until a non-negative value or re-optimisation reset is encountered.

        Returns
        -------
        tuple
            ``(pct_change, re_optimize_flag)``
        """
        re_optimize_flag = False

        prev_total = 0
        # Walk backwards until the last re-balance to accumulate negative percent changes
        for idx in reversed(range(results_dataframe.shape[0])):
            if results_dataframe['pct_change'].iloc[idx] < 0 and not results_dataframe['re_optimized'].iloc[idx]: 
                prev_total += results_dataframe['pct_change'].iloc[idx]
            else:
                break

    #     print(f'cumulative negative pct change is {prev_total}')
        if pct_change < self.re_optimize_threshold or prev_total + pct_change < self.re_optimize_threshold: 
            re_optimize_flag = True
            
        return pct_change, re_optimize_flag
    
    def _check_drift_from_optimal(self, optimal_portfolio, backtest_idx):
        """
        Measure deviation between the on-the-fly *current* portfolio (after
        market moves) and the last *optimal* weight vector.

        Parameters
        ----------
        optimal_portfolio : portfolio.Portfolio
            Portfolio immediately *after* the most recent optimisation.
        backtest_idx : int
            Integer index into :pyattr:`price_data`.  Aligns daily price moves
            with ``look_forward_window`` stride.

        Returns
        -------
        tuple
            ``(deviation, re_optimize_flag)``
        """
        re_optimize_flag = False

        # Ratio of *today's* price to price *after future window*
        price_change = self.price_data.iloc[backtest_idx].div(self.price_data.iloc[backtest_idx + self.look_forward_window])

        # Apply relative price change to weight vector (simulates drift)
        cur_portfolio_weights = price_change.to_numpy() * optimal_portfolio.weights

#         for idx, weight in enumerate(cur_portfolio_weights):
#             ticker = optimal_portfolio.tickers[idx]
#             if np.abs(weight) > 1e-3:
#                 print(f'{ticker}: {weight}')

        # Deviation metric (L1 or L2) against *previous* optimal weights
        if self.re_optimize_criteria['norm'] == 2:
            deviation = np.sum(np.abs(cur_portfolio_weights - optimal_portfolio.weights)**2) #squared differences
        elif self.re_optimize_criteria['norm'] == 1:
            deviation = np.sum(np.abs(cur_portfolio_weights - optimal_portfolio.weights)) #1-norm
        
        if deviation > self.re_optimize_threshold:
            re_optimize_flag = True
        
        return deviation, re_optimize_flag
    
    def _check_max_drawdown(self, mdd):
        re_optimize_flag = False
        
        if mdd > self.re_optimize_threshold: 
            re_optimize_flag = True
            
        return re_optimize_flag
    
    def plot_results(self, results_dataframe, re_optimize_dates):
        """
        Plot cumulative portfolio value under the *dynamic* strategy against
        the *static* no-re-balance benchmark, with vertical markers showing
        re-optimisation dates.
        """
        fig, ax = plt.subplots()
        
        sns.lineplot(results_dataframe['portfolio_value'], marker = "*", markersize = 10, ax=ax, zorder = 3)
        sns.lineplot(self.no_reoptimize_results['portfolio_value'], linewidth= 1, linestyle='-', ax=ax, zorder =2)
        
        colors = [line.get_color() for line in ax.get_lines()]
        
        for date in re_optimize_dates:
            ax.axvline(x = date, linestyle = '--', color = 'r', zorder =1)
            
        handles, labels = ax.get_legend_handles_labels()

        # Legend customization
        line1_handle = Line2D([], [], color = colors[0], marker="*", linestyle='None', label = 'backtest dates')
        line2_handle = Line2D([], [], color = colors[1], linestyle='-', label = 'no re-optimize')
        vline_handle = Line2D([], [], color='red', linestyle='--', label = 're-optimize dates')
        
        
        ax.tick_params(axis='x', labelrotation=45)
        ax.legend(handles=[line1_handle, line2_handle, vline_handle])
        ax.set_xlabel('Date')
        ax.set_ylabel('Portfolio Value')
    
    def _get_no_reoptimize_results(self):
        """
        Internal helper that reruns :meth:`re_optimize` with
        ``run_re_optimize=False`` so that downstream methods can always
        access a *static* benchmark track without rebuilding it.
        """
        print("*****Testing No Re-Optimize*****")
        no_reoptimize_results_dataframe, re_optimize_dates = self.re_optimize(plot_results = False, existing_portfolio = None, run_re_optimize = False)
        return no_reoptimize_results_dataframe
    
    def plot_weights_vs_prices(self, re_optimize_results, ticker):
        """
        Super-impose the evolving weight of *ticker* against its price series.
        """
        assert ticker in self.price_data.columns, "The selected ticker is not in the asset universe!"
        
        ticker_idx = list(self.price_data.columns).index(ticker)
        ticker_weights_history = [current_portfolio.weights[ticker_idx] for current_portfolio in re_optimize_results['optimal_portfolio'].iloc[1:]]
        fig, ax1 = plt.subplots(figsize=(12, 6))
        plot_start_date = re_optimize_results.index[1]
        plot_end_date = re_optimize_results.index[-1]
        price_data = self.price_data.loc[plot_start_date: plot_end_date, ticker]
        ax1.plot(price_data, color = 'red', label = f'{ticker} prices')
        ax1.set_title(f'{ticker} weights vs. prices')
        
        ax2 = ax1.twinx()
        ax2.bar(re_optimize_results.index[1:], ticker_weights_history, color='#76b900', width = 30, label = f'{ticker}', alpha=0.7)
        ax2.axhline(y=0, color = 'black', linewidth = 0.8)
        ax1.legend()
        ax2.legend()
        # Show the plot
        plt.tight_layout()
        plt.show()


def compare_portfolios(ptf1, ptf2, name1, name2): 
    """
    Bar-plot two portfolios side-by-side (including cash).

    Returns
    -------
    pandas.DataFrame
        Index = tickers + 'Cash'.
    """
    assert ptf1.tickers == ptf2.tickers, "Must be the same asset universe!"
    
    alloc1 = np.append(ptf1.weights, ptf1.cash)
    alloc2 = np.append(ptf2.weights, ptf2.cash)
    
    tickers = ptf1.tickers.copy()
    tickers.append('Cash')
    
    # Transpose the DataFrame so that columns become features and rows become categories
    compare_df = pd.DataFrame({name1: alloc1, name2: alloc2}, index = tickers)
    df_melted = compare_df.reset_index().melt(id_vars='index', var_name='Portfolio', value_name='Value')
    # Plot using Seaborn barplot
    plt.figure(figsize=(8, 6))
    sns.barplot(x='index', y='Value', hue='Portfolio', data=df_melted, dodge=True, width=0.4)
    plt.axhline(0, color='black', linewidth=1)
    plt.xticks(compare_df.index)
    # Add labels and title
    plt.title(f'{name1} vs. {name2}')
    plt.xlabel('Tickers')
    plt.ylabel('Portfolio Weights')
    
    return compare_df

def compare_difference(ptf1, ptf2, base_ptf, name1, name2): 
    """
    Visualise *difference from a base* portfolio for both **ptf1** and **ptf2**.

    Useful for attributing *relative* bets rather than absolute weights.

    Returns
    -------
    pandas.DataFrame
        Same structure as :func:`compare_portfolios` but showing deltas.
    """
    assert ptf1.tickers == ptf2.tickers, "Must be the same asset universe!"
    
    weights_diff_1 = ptf1.weights - base_ptf.weights
    weights_diff_2 = ptf2.weights - base_ptf.weights
    
    cash_diff_1 = ptf1.cash - base_ptf.cash
    cash_diff_2 = ptf2.cash - base_ptf.cash
    
    alloc1 = np.append(weights_diff_1, cash_diff_1)
    alloc2 = np.append(weights_diff_2, cash_diff_2)
    
    tickers = ptf1.tickers.copy()
    tickers.append('Cash')
    # Transpose the DataFrame so that columns become features and rows become categories
    compare_df = pd.DataFrame({name1: alloc1, name2: alloc2}, index = tickers)
    df_melted = compare_df.reset_index().melt(id_vars='index', var_name='Portfolio', value_name='Value')
    # Plot using Seaborn barplot
    plt.figure(figsize=(8, 6))
    sns.barplot(x='index', y='Value', hue='Portfolio', data=df_melted, dodge=True, width=0.4)
    plt.axhline(0, color='black', linewidth=1)
    plt.xticks(compare_df.index)
    # Add labels and title
    plt.title(f'{name1} vs. {name2}')
    plt.xlabel('Tickers')
    plt.ylabel('Portfolio Weights Difference')
    
    return compare_df

    
