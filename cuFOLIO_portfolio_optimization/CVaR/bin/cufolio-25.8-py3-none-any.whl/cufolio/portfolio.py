'''
SPDX-FileCopyrightText: Copyright (c) 2021-2025 NVIDIA CORPORATION &
AFFILIATES. All rights reserved. SPDX-License-Identifier:
LicenseRef-NvidiaProprietary

NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
property and proprietary rights in and to this material, related
documentation and any modifications thereto. Any use, reproduction,
disclosure or distribution of this material and related documentation
without an express license agreement from NVIDIA CORPORATION or
its affiliates is strictly prohibited.
'''

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import json

class Portfolio:
    """
    Immutable data **attributes**

    ===============  ========================================================
    ``name``         (str)   Human-readable identifier.
    ``tickers``      (list)  List of ticker symbols recognised by the rest
                             of the stack, **order matters**.
    ``weights``      (ndarray, shape=(n_assets,)) Position weights for the
                             tickers in the **same order**.  Positive values
                             are long, negative short, cash excluded.
    ``cash``         (float) Residual cash position.  A fully invested, long-
                             only portfolio will usually have ``cash == 0``.
    ``time_range``   (tuple | None) Optional (start_date, end_date) for plots.
    ===============  ========================================================

    Notes
    -----
    * All portfolio operations assume **self-financing** (`Σweights + cash = 1`)
      and will raise if violated.
    * Default arguments use mutable containers (`tickers=[]` etc.).  These are
      safe here because the constructor overwrites them in-place, but be aware
      of the usual Python gotcha if you subclass or extend.

    Examples
    --------
    >>> ptf = Portfolio(name='demo',
    ...                 tickers=['AAPL', 'NVDA'],
    ...                 weights=np.array([0.6, 0.3]),
    ...                 cash=0.1)
    >>> exp_ret = ptf.calculate_portfolio_expected_return(mean=np.array([0.05, 0.07]))
    >>> var     = ptf.calculate_portfolio_variance(covariance=np.eye(2)*0.04)
    >>> ptf.plot_portfolio(show_plot=True)
    """
    def __init__(self, name='', tickers=[], weights=[], cash=0.0, time_range = None):
        """
        Parameters
        ----------
        name : str, optional
            Portfolio label.
        tickers : list[str], optional
            Ordered list of asset tickers.  Length defines ``n_assets``.
        weights : array-like, optional
            Initial weights.  If empty, will be lazily filled later.
        cash : float, optional
            Initial cash position (defaults to *fully invested* 0.0).
        time_range : tuple[str, str] | None, optional
            `(start, end)` date strings used only for labelling plots.
        """
        self.name = name  # Portfolio name or ''
        self.tickers = tickers
        self._n_assets = len(self.tickers)
        self.weights = weights 
        self.cash = float(cash)
        self.time_range = time_range
    
    def __eq__(self, other_portfolio, atol = 1e-3):
        """
        Equality based **solely** on the weight vector (within `atol`).

        The cash position, name, etc. are ignored to let users compare
        “economic equivalence” rather than metadata.

        Parameters
        ----------
        other_portfolio : Portfolio
            The portfolio to compare against.
        atol : float, default=1e-3
            Absolute tolerance passed to :func:`numpy.allclose`.

        Returns
        -------
        bool
            ``True`` if the weight vectors are element-wise close.
        """
        if isinstance(other_portfolio, Portfolio):
            return np.allclose(self.weights, other_portfolio.weights, atol = atol)
        return False
    
    def _check_self_financing(self, weights = [], cash = None):
        """
        Validate the self-financing constraint (Σweights + cash == 1).

        Called by mutator methods before persisting new state.

        Parameters
        ----------
        weights : array-like, optional
            Proposed weights.  Empty list falls back to ``self.weights``.
        cash : float | None, optional
            Proposed cash.  ``None`` falls back to ``self.cash``.

        Raises
        ------
        ValueError
            If the portfolio fails the constraint by more than 1e-3.
        """
        # Allow empty `weights` sentinel to simplify external calls
        if len(weights) == 0:
            weights = self.weights
        # Default to current cash if not supplied
        if cash is None: 
            cash = self.cash
        
        self_finance = np.sum(weights) + cash

        if np.abs(self_finance - 1) > 1e-3:
            print(f'weights: {np.sum(weights)}; cash: {cash}')
            raise ValueError("Portfolio weights and cash do not sum to 1!")
        
    def portfolio_from_dict(self, portfolio_name, user_portfolio_dict, cash):
        """
        Populate the object from a *{ticker: weight}* mapping.

        Parameters
        ----------
        portfolio_name : str
            Name to assign to ``self.name``.
        user_portfolio_dict : dict[str, float]
            Mapping of tickers (case-insensitive) to **pre-cash** weights.
        cash : float
            Cash allocation that will be checked together with weights.

        Raises
        ------
        ValueError
            If the dictionary contains tickers outside ``self.tickers`` or
            if the resulting (weights + cash) fails self-financing.
        """
        # Initialise an empty weight series aligned to known tickers
        weights = pd.Series(dtype = np.float64, index = self.tickers)
        # Fill weights from the user dictionary (case-insensitive lookup)
        for ticker, weight in user_portfolio_dict.items():
            ticker = ticker.upper()
            if ticker in self.tickers:
                weights[ticker] = weight
            else: 
                raise ValueError('Selected ticker is not available in the dataset!')

        weights = weights.fillna(0).T
        weights = weights.to_numpy()

        # Validate before writing
        self._check_self_financing(weights, cash)
        
        self.weights = np.array(weights)
        self.cash = float(cash)
        self.name = portfolio_name
    
    def print_clean(self, cutoff = 1e-3, rounding = 3, verbose=False):
        """
        Return a *clean* dictionary of positions, optionally print it.

        *Cutoff* removes micro-positions that clutter output and plots.

        Parameters
        ----------
        cutoff : float, default=1e-3
            Absolute threshold below which a weight is treated as zero.
        rounding : int, default=3
            Number of decimal places for printing.
        verbose : bool, default=False
            If ``True`` print long/short positions to stdout.

        Returns
        -------
        tuple(dict[str, float], float)
            Cleaned position dictionary **excluding cash** and the rounded
            cash amount.
        """
        residual = 0
        clean_ptf_dict = {}
        for idx, ticker in enumerate(self.tickers):
            value = self.weights[idx]
            if value > cutoff:
                clean_ptf_dict[ticker] = value
                if verbose:
                    print(f'Long--{ticker}: {value.round(rounding)}')
                
            elif value < -cutoff:
                clean_ptf_dict[ticker] = value
                if verbose:
                    print(f'Short--{ticker}: {value.round(rounding)}')
            else: 
                residual += value  # For completeness (rarely non-zero)
        
        cash = round(self.cash, rounding)
        
        if verbose:
            print(f'cash: {cash}')
        
        return (clean_ptf_dict, float(cash))
    
    def calculate_portfolio_expected_return(self, mean):
        """
        Compute the *scalar* portfolio expected return.

        Parameters
        ----------
        mean : ndarray, shape=(n_assets,)
            Expected returns of individual assets **aligned to tickers**.

        Returns
        -------
        float
            Portfolio expected return (`wᵀ μ`).

        Raises
        ------
        AssertionError
            If the mean vector does not match ``n_assets``.
        """
        assert (mean.shape[0] == self._n_assets), f'Incorrect mean vector size! Expecting: {self._n_assets}.'
        
        return mean @ self.weights
    
    def calculate_portfolio_variance(self, covariance):
        """
        Compute the *scalar* portfolio variance.

        Parameters
        ----------
        covariance : ndarray, shape=(n_assets, n_assets)
            Asset return covariance matrix aligned to tickers.

        Returns
        -------
        float
            Portfolio variance (`wᵀ Σ w`).

        Raises
        ------
        AssertionError
            If the covariance dimensions are incompatible.
        """
        assert (covariance.shape[0] == self._n_assets or covariance.shape[1] != self._n_assets),\
                f'Incorrect covariance size! Expecting: {self._n_assets} by {self._n_assets}.'
        
        return self.weights.T @ covariance @ self.weights

    def plot_portfolio(self, show_plot = False, ax = None, title = None):
        """
        Draw a horizontal bar chart of portfolio weights + cash.

        Long positions are coloured NVIDIA green, shorts red, cash green.

        Parameters
        ----------
        show_plot : bool, default=False
            Call :pyfunc:`matplotlib.pyplot.show` before returning.
        ax : matplotlib.axes.Axes | None, optional
            Existing axes to draw on; if *None* a new figure is created.
        title : str | None, optional
            Custom title.  If omitted and ``time_range`` is set, a default
            “Portfolio from *start* to *end*” is generated.

        Returns
        -------
        matplotlib.axes.Axes
            The axes (handy for caller-side styling or saving).
        """
        if ax is None:
            fig, ax = plt.subplots(figsize=(10, 6))

        # If the portfolio is huge, compress to >cutoff positions only
        if self._n_assets <= 30: 
            tickers = self.tickers
            weights = self.weights
            cash = self.cash
        else: 
            portfolio = self.print_clean()
            tickers = list(portfolio[0].keys())
            weights = list(portfolio[0].values())
            cash = portfolio[1]

        # Positive weights = long (green), negative = short (red)
        colors = ['#76b900' if value >= 0 else 'r' for value in weights]
        ax.barh(tickers, weights, color = colors)
        ax.barh('cash', cash, color = '#76b900')
        
        ax.set_ylabel('Tickers', fontsize = 8)
        ax.set_xlabel('Portfolio Weights', fontsize = 8)
        if self.time_range is not None:
            start = self.time_range[0]
            end = self.time_range[1]
            if title is None:
                title = f'Portfolio from {start} to {end}'

            ax.set_title(title, fontsize = 10)
            
        ax.set_xlim(-1, 1)
        ax.axvline(0, color = "k")
        ax.tick_params(axis='both', labelsize=8)
        
        if show_plot:
            plt.show()
        
        return ax
    
    def save_portfolio(self, save_path):
        """
        Serialize the portfolio to a **human-readable** JSON file.

        Parameters
        ----------
        save_path : str | PathLike
            Destination filename; parent directories must exist.
        """
        save_weights = self.weights.tolist()
        
        portfolio = {'name': self.name, 'weights': save_weights, 'cash': self.cash, 'tickers': self.tickers, 'time_range': self.time_range}
        
        with open(save_path, 'w') as json_file:
            json.dump(portfolio, json_file, indent=4)
            
    def load_portfolio_from_json(self, load_path): 
        """
        Load portfolio state from a JSON file and overwrite **in-place**.

        Parameters
        ----------
        load_path : str | PathLike
            Source filename.

        Raises
        ------
        ValueError
            If the JSON fails the self-financing check.
        """
        with open(load_path, 'r') as json_file:
            data = json.load(json_file)

        # Restore attributes
        self.name = data['name']
        self.tickers = data['tickers']
        self._n_assets = len(self.tickers)
        weights = np.array(data['weights'])
        # Sanity-check before persisting
        self._check_self_financing(weights, data['cash'])
        self.weights = weights
        self.cash = data['cash']
        self.time_range = data['time_range']