'''
SPDX-FileCopyrightText: Copyright (c) 2021-2025 NVIDIA CORPORATION &
AFFILIATES. All rights reserved. SPDX-License-Identifier:
LicenseRef-NvidiaProprietary

NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
property and proprietary rights in and to this material, related
documentation and any modifications thereto. Any use, reproduction,
disclosure or distribution of this material and related documentation
without an express license agreement from NVIDIA CORPORATION or
its affiliates is strictly prohibited.
'''

"""
Module: CVaR Optimization
=========================
This module implements data structures and a class for **Conditional Value‑at‑Risk (CVaR)** portfolio optimization.
A CVaR optimizer chooses asset weights that control downside risk while maximizing expected return (or, equivalently, minimizing a risk‑penalised loss).

Key features
------------
* Pure Python / NumPy formulation that can be solved **on CPU** with CVXPY or **on GPU** with NVIDIA cuOpt.
* Support for *hard* and *soft* risk constraints:
  * **Hard** – explicit CVaR limit, turnover cap, leverage cap.
  * **Soft** – CVaR penalty embedded in the objective ("risk‑aversion").
* Automatic rescaling of the risk‑aversion coefficient so that user supplied
  values remain meaningful regardless of the scale of the input data.
* Serialisation helpers that write/read the linear programme to disk so that the
  heavy algebra can be done once on CPU and later solved repeatedly on GPU.

Public classes
--------------
``CVaR_Data``
    Lightweight container for scenario inputs (mean, covariance, scenario matrix *R*, probabilities *p*).
``CVaR_Parameters``
    User configurable knobs and dials: weight bounds, cash bounds, turnover
    target, leverage target, CVaR limit, risk aversion, confidence level, etc.
``CVaR``
    The optimizer itself.  Sub‑classes ``BaseOptimizer`` for shared plumbing and
    exposes ``solve_optimization_problem`` as the user entry point.
"""
from dataclasses import dataclass
import datetime as dt
import os
import json
import copy 

import numpy as np
import pandas as pd
import math
import scipy
from scipy.stats import norm
from scipy.sparse import csr_matrix
import cvxpy as cp

import matplotlib.pyplot as plt
import seaborn as sns

from . import base_optimizer, cvar_utils, utils
from .portfolio import Portfolio

from cuopt import linear_programming as lp
import time

import msgpack # msgpack was used for the old dictionary-based model

FILE_FORMAT = '.json'

@dataclass 
class CVaR_Data: 
    """
    Data structure holding all scenario and statistical information required for CVaR optimization.

    Attributes
    ----------
    mean : np.ndarray
        Array of shape (n_assets,) of expected asset returns.
    covariance : np.ndarray
        Covariance matrix of shape (n_assets, n_assets) of asset returns.
    R : np.ndarray
        Scenario deviations, shape (num_scenarios, n_assets),
        each row is asset return deviation for a scenario.
    p : np.ndarray
        Scenario probabilities, shape (num_scenarios,), summing to 1.
    """
    mean: np.ndarray
    covariance: np.ndarray
    R: np.ndarray
    p: np.ndarray

@dataclass
class CVaR_Parameters:
    """
    User‑tunable parameters and constraint limits for CVaR optimization.
    All numerical parameters are *scalars* except ``w_min`` / ``w_max`` which are length‑*n_assets* arrays.
    """

    # Weight / cash bounds ---------------------------------------------------
    w_min: np.ndarray      # Lower bound for each risky weight
    w_max: np.ndarray      # Upper bound for each risky weight   
    c_min: float           # Lower bound for cash allocation
    c_max: float           # Upper bound for cash allocation
    # Soft / hard constraint targets ----------------------------------------
    T_tar: float           # Turnover cap (L1 distance to previous weights)   
    L_tar: float           # Leverage cap (Σ|wᵢ|)   
    cvar_limit:float       # Hard CVaR limit (None means "no hard limit")
    # Risk model controls ----------------------------------------------------
    risk_aversion: float   # λ – penalty applied to CVaR inside objective
    confidence: float      # α in CVaR_α (e.g. 0.95 ⇒ 95 % CVaR)
    num_scen: int          # Number of Monte‑Carlo / historical scenarios
    fit_type: str          # Scenario generation method tag
        
    def update_w_min(self, new_w_min):
        """Overwrite the lower bound vector for risky asset weights."""
        self.w_min = new_w_min
    
    def update_w_max(self, new_w_max):
        """Overwrite the upper bound vector for risky asset weights.
        ------
        ValueError
            If *any* entry exceeds 100 % (weights are expressed as fractions).
        """
        if new_w_max <= 1:
            self.w_max = new_w_max
        else:
            raise ValueError('Invalid upper bound for weights!')
        
    def update_c_min(self, new_c_min):
        """Set new lower bound for cash weight (must be non‑negative)."""
        if new_c_min >= 0: 
            self.c_min = new_c_min
        else: 
            raise ValueError('Cash should be non-negative!')
    
    def update_c_max(self, new_c_max):
        """Set new upper bound for cash weight.
        Cash is itself an asset; admissible domain is ``[0, 1]``.
        """
        if new_c_max >= 0 and new_c_max <= 1:
            self.c_max = new_c_max
        else:
            raise ValueError('Invalid upper bound for cash!')

    # --- Internal helper aliases (used by the LP builder) -------------------
    def update_z_min(self, new_c_min):
        """Alias exposing the same setter semantics for internal variable *z*."""
        self.z_min = new_c_min
    
    def update_z_max(self, new_z_max):
        """Alias exposing the same setter semantics for internal variable *z*."""
        self.z_max = new_z_max

    # --- Soft constraints ---------------------------------------------------
    def update_T_tar(self, new_T_tar):
        """Change turnover target (L1 distance between old/new weights)."""
        self.T_tar = new_T_tar
        
    def update_L_tar(self, new_L_tar):
        """Change leverage target (Σ|wᵢ|)."""
        self.L_tar = new_L_tar
    
    def update_risk_aversion(self, new_risk_aversion):
        """Change λ, the coefficient multiplying CVaR in the objective.
        -----
        *λ > 0* corresponds to a convex risk penalty.  Zero would remove CVaR from the objective which is not allowed here.
        """
        if new_risk_aversion > 0:
            self.risk_aversion = new_risk_aversion
        else:
            raise ValueError('Invalid risk aversion')
    
    def update_num_scen(self, new_num_scen):
        """
        Update number of scenarios.
        Raises:
            ValueError: If new_num_scen <= 0.
        """
        if new_num_scen > 0: 
            self.num_scen = new_num_scen
        else: 
            raise ValueError('Invalid risk aversion')
            
    def update_confidence(self, new_confidence):
        """Change the CVaR confidence level *α*.
        ``α`` must lie in the open interval ``(0, 1]``.
        """
        if new_confidence > 0 and new_confidence <= 1:
            self.confidence = new_confidence
        else: 
            raise ValueError('Invalid confidence level (should be between 0 and 1, e.g. 95%, 99%, etc.)')


class CVaR(base_optimizer.BaseOptimizer):
    """
    Conditional Value-at-Risk (CVaR) portfolio optimizer.

    Sets up and solves portfolio optimization problems that either
    minimize CVaR or maximize return under a CVaR penalty/constraint.
    Supports CPU (CVXPY) and GPU (cuOpt) solvers, with optional turnover,
    leverage, and hard CVaR constraints.
    """
    def __init__(self, returns_dict, cvar_params, problem_from_file = None, existing_portfolio = None):
        """Instantiate a ``CVaR`` optimiser.

        Parameters
        ----------
        returns_dict
            Dictionary returned by upstream data‑prep code.  Must contain keys
            ``'regime'`` (with sub‑keys ``'name'`` and ``'range'``) and
            ``'cvar_data'`` (``CVaR_Data`` instance).
        cvar_params
            User‑supplied parameter object (will be *deep‑copied* for safety).
        problem_from_file
            If *not None*, path (without extension) pointing to a serialized
            cuOpt problem previously written by ``_save_problem_for_cuopt``.
            The LP matrices/bounds will be *loaded* instead of rebuilt.
        existing_portfolio
            Previous portfolio weights – required when imposing a *turnover*
            constraint.  Ignored otherwise.
        """
        super().__init__(returns_dict, existing_portfolio, 'CVaR')

        self.regime_name = returns_dict['regime']['name']    # Name of the market regime (e.g., 'covid', 'recent')
        self.regime_range = returns_dict['regime']['range']  # Tuple (start_date, end_date) for the regime
        self.data = returns_dict['cvar_data']                # CVaR_Data object with mean, covariance, scenarios
        self.existing_portfolio = existing_portfolio         # Previous portfolio weights for turnover calculation
        self.params = copy.deepcopy(cvar_params)             # Deep copy of CVaR_Parameters to avoid external modifications
        
        self.problem_from_file = problem_from_file           # Solve the problem from file or set up the problem if None
        
        # Set up or load the optimization problem
        self._set_up()

        # Will store the optimized Portfolio object
        self.optimal_portfolio = None
        # DataFrame to store custom evaluated portfolios if any
        self.custom_portfolios = pd.DataFrame([], columns = ['portfolio_name', 'weights', 'cash', 'return', 'variance', 'CVaR'])
        
        # Stores the CVXPY problem object if CPU solver is used
        self._cpu_problem = None
        
        # Columns for the DataFrame that stores optimization results
        self._result_columns = ['regime', 'solve time', 'return',  'CVaR', 'obj']
        
        
    def _set_up(self):
        """
        Prepare the optimization problem for solution.

        This method detects which constraints apply and either:
          - Builds objective and constraint matrices from scratch for the current parameters, or
          - Loads a problem definition from file if `self.problem_from_file` is set.

        Determines which type of CVaR problem is required (basic, with cvar limit, with turnover, etc).
        """
        if self.problem_from_file is None:
            set_up_start = time.time()   # Record setup start time
            self._scale_risk_aversion()  # Adjust risk aversion parameter based on data characteristics
            
            # Determine the problem formulation based on specified parameters
            # 1. basic cvar
            # 2. cvar with constraint on cvar limit
            # 3. cvar with constraints on cvar limit and tracking error
            if self.params.cvar_limit is None and self.params.T_tar is None: 
                problem_flag = 'basic cvar'
            elif isinstance(self.params.cvar_limit, float) and self.params.T_tar is None:
                problem_flag = 'cvar with limit'
            elif isinstance(self.params.cvar_limit, float) and isinstance(self.params.T_tar, float):
                if self.existing_portfolio is not None:
                    problem_flag = 'cvar with limit and turnover'
                else:
                    print('No existing portfolio: no turnover constraint imposed.')
                    problem_flag = 'cvar with limit'
                    
            elif self.params.cvar_limit is None and isinstance(self.params.T_tar, float): 
                problem_flag = 'cvar with turnover'
            else:
                raise ValueError('check cvar_limit and/or tracking error.')
            
            # Set up the selected problem 
            self._set_up_optimization_problem(problem_flag)
            
            set_up_end = time.time()
            set_up_time = set_up_end - set_up_start
            #print(f'{problem_flag} problem set up! Completed in {set_up_time:.2f} seconds.')
        else: 
            self.read_problem_from_file()
            print(f'Problem read from file!')
            
    def _scale_risk_aversion(self):
        """Auto‑rescale λ so that its *effective* weight is data‑scale invariant.

        We compute CVaR and expected return for each individual asset held at
        100 % weight.  The **max** ratio of ``return / CVaR`` across these
        single‑asset portfolios gives a heuristic conversion factor so that a
        user‑provided λ "behaves" similarly on data with different units.
        """
        single_portfolio_performance = cvar_utils.evaluate_single_asset_portfolios(self)
        scalar = (single_portfolio_performance['return'] / single_portfolio_performance['CVaR']).max()
        
        self.params.update_risk_aversion(self.params.risk_aversion * scalar)
#       print(f'adjusted risk aversion: {self.params.risk_aversion}')
        
    def _set_up_optimization_problem(self, problem_flag):
        """Create objective vector and constraint matrices for a given variant.

        Parameters
        ----------
        problem_flag
            One of ``'basic cvar'``, ``'cvar with limit'``, ``'cvar with turnover'`` or
            ``'cvar with limit and turnover'``.

        Notes
        -----
        *N* = number of assets, *M* = number of scenarios.
        """
        N = self.n_assets
        M = len(self.data.p)

        # -------------------------------------------------------------
        # 1) Objective vector d  (minimise dᵀx)
        # -------------------------------------------------------------
        if problem_flag in ['cvar with limit', 'basic cvar']:
            # Objective vector with penalty on transaction cost
            d = np.concatenate([
                -self.data.mean.T,                   # size N
                [0],                                 # size 1
                [self.params.risk_aversion],         # size 1
                (self.params.risk_aversion / (1 - self.params.confidence)) * self.data.p,  # size M
                np.zeros(N)                          # size N
            ])
        
        # -------------------------------------------------------------
        # 2) Inequality / equality constraints
        # -------------------------------------------------------------
        # For each variant we stack blocks building Gx ≤ h  and  Ax = b.
        # The math comes from the standard linearisation of CVaR with
        # leverage/turnover extras.  Only the composition of blocks differs.
        # -------------------------------------------------------------
        if problem_flag == 'basic cvar':
            # --------------------------------------------------
            #   Gx ≤ h    (no hard CVaR, no turnover)
            # --------------------------------------------------
            G = np.vstack([
                np.hstack([self.data.R.T, np.zeros((M, 1)), np.ones((M, 1)), np.eye(M), np.zeros((M, N))]),  
                np.hstack([-np.eye(N), np.zeros((N, 1)), np.zeros((N, 1)), np.zeros((N, M)), np.eye(N)]),
                np.hstack([np.eye(N), np.zeros((N, 1)), np.zeros((N, 1)), np.zeros((N, M)), np.eye(N)])
            ])

            # Right‑hand side (all zeros)
            h = np.zeros(G.shape[0])

            # ----------------------  Ax = b -----------------------
            A = np.vstack([
                np.hstack([np.ones((1, N)), [[1]], [[0]], np.zeros((1, M)), np.zeros((1, N))]),
                np.hstack([np.zeros((1, N)), [[0]], [[0]], np.zeros((1, M)), np.ones((1, N))])
            ])

            # convert ≤ to ≥ with sign flip for cuOpt
            A = np.vstack((A, -G))

            b = np.array([1, self.params.L_tar])
            b = np.hstack([b, -h])    # add slack for inequalities turned equality
            self._equality_index = 2  # first two rows are equalities

            lower_bound_b = ['ninf' for _ in b]
            lower_bound_b[0] = 1      # self-financing: budget equality becomes lower==upper
            
            # Variables constraints' upper and lower bound
            lower = np.concatenate([np.full(N, self.params.w_min), [self.params.c_min], [-np.inf], np.full(M, 0), np.zeros(N)])
            upper = np.concatenate([np.full(N, self.params.w_max), [self.params.c_max], [np.inf], np.full(M, np.inf), np.full(N, self.params.w_max)])

        # ..................................................................
        # Subsequent variants add hard CVaR and/or turnover – all follow the
        # same building pattern so only inline comments are added for the
        # *differences* to keep this file concise.
        # ..................................................................
        elif problem_flag == 'cvar with limit':
            # Hard CVaR ⇒ extra row in G enforcing t + 1/(1−α) Σ p_i u_i ≤ cvar_limit
            # Everything else identical to basic case.
            G = np.vstack([
                np.hstack([self.data.R.T, np.zeros((M, 1)), np.ones((M, 1)), np.eye(M), np.zeros((M, N))]),  # R (N,M), transpose to fit
                np.hstack([-np.eye(N), np.zeros((N, 1)), np.zeros((N, 1)), np.zeros((N, M)), np.eye(N)]),
                np.hstack([np.eye(N), np.zeros((N, 1)), np.zeros((N, 1)), np.zeros((N, M)), np.eye(N)]),
                np.hstack([np.zeros((1,N)), [[0]], [[-1]], [1/(self.params.confidence-1) * self.data.p.T], np.zeros((1,N))])
            ])

            # h vector
            h = np.zeros(G.shape[0])
            h[-1] = -self.params.cvar_limit  # negate because row formulated ≤ 0

            # A identical to basic case ---------------------------------------
            A = np.vstack([
                np.hstack([np.ones((1, N)), [[1]], [[0]], np.zeros((1, M)), np.zeros((1, N))]),
                np.hstack([np.zeros((1, N)), [[0]], [[0]], np.zeros((1, M)), np.ones((1, N))])
            ])

            A = np.vstack([A, -G])

            b = np.array([1, self.params.L_tar])
            b = np.hstack([b, -h])
            self._equality_index = 2
            
            lower_bound_b = ['ninf' for _ in b]
            lower_bound_b[0] = 1 #self-financing
            
            # Variables constraints' upper and lower bound
            lower = np.concatenate([np.full(N, self.params.w_min), [self.params.c_min], [-np.inf], np.full(M, 0), np.zeros(N)])
            upper = np.concatenate([np.full(N, self.params.w_max), [self.params.c_max], [np.inf], np.full(M, np.inf), np.full(N, self.params.w_max)])
            
            
        elif problem_flag == 'cvar with turnover':
            # Objective vector adds a second |Δw| block (no cost) --------------
            d = np.concatenate([
                -self.data.mean.T,                   # size N
                [0],                                 # size 1
                [self.params.risk_aversion],         # size 1
                (self.params.risk_aversion / (1 - self.params.confidence)) * self.data.p,  # size M
                np.zeros(N),                         # size N            #leverage
                np.zeros(N)                          # size N            #turnover
            ])

            w_prev = np.array(self.existing_portfolio.weights)
            
            G = np.vstack([
                np.hstack([self.data.R.T, np.zeros((M, 1)), np.ones((M, 1)), np.eye(M), np.zeros((M, N)), np.zeros((M,N))]),  
                # R (N,M), transpose to fit
                np.hstack([-np.eye(N), np.zeros((N, 1)), np.zeros((N, 1)), np.zeros((N, M)), np.eye(N), np.zeros((N, N))]),
                np.hstack([np.eye(N), np.zeros((N, 1)), np.zeros((N, 1)), np.zeros((N, M)), np.eye(N), np.zeros((N, N))]),
                np.hstack([np.eye(N), np.zeros((N, 1)), np.zeros((N, 1)), np.zeros((N, M)), np.zeros((N,N)), np.eye(N)]),
                np.hstack([-np.eye(N), np.zeros((N, 1)), np.zeros((N, 1)), np.zeros((N, M)), np.zeros((N,N)), np.eye(N)])
            ])

            # h vector
            h = np.hstack([np.zeros(M), np.zeros(N), np.zeros(N), w_prev, -w_prev])            

            # Define A matrix and b vector
            A = np.vstack([
                np.hstack([np.ones((1, N)), [[1]], [[0]], np.zeros((1, M)), np.zeros((1, N)), np.zeros((1, N))]),
                np.hstack([np.zeros((1, N)), [[0]], [[0]], np.zeros((1, M)), np.ones((1, N)), np.zeros((1, N))]),
                np.hstack([np.zeros((1, N)), [[0]], [[0]], np.zeros((1, M)), np.zeros((1, N)), np.ones((1, N))]),
            ])
            
            A = np.vstack([A, -G])
            
            b = np.array([1, self.params.L_tar, self.params.T_tar])
            b = np.hstack([b, -h])
            self._equality_index = 3
            
            #lower bound required for cuopt
            lower_bound_b = ['ninf' for _ in b]
            lower_bound_b[0] = 1 #self-financing
            
            # Variables constraints' upper and lower bounds
            lower = np.concatenate([np.full(N, self.params.w_min), [self.params.c_min], [-np.inf], np.full(M, 0), np.zeros(N), np.zeros(N)])
            upper = np.concatenate([np.full(N, self.params.w_max), [self.params.c_max], [np.inf], np.full(M, np.inf), np.full(N, self.params.w_max), np.full(N, self.params.T_tar)])
            
        elif problem_flag == 'cvar with limit and turnover':
            # Hybrid = previous + hard CVaR row --------------------------------
            d = np.concatenate([
                -self.data.mean.T,                   # size N
                [0],                                 # size 1
                [self.params.risk_aversion],         # size 1
                (self.params.risk_aversion / (1 - self.params.confidence)) * self.data.p,  # size M
                np.zeros(N),                         # size N
                np.zeros(N)                          # size N
            ])

            w_prev = np.array(self.existing_portfolio.weights)
            
            G = np.vstack([
                np.hstack([self.data.R.T, np.zeros((M, 1)), np.ones((M, 1)), np.eye(M), np.zeros((M, N)), np.zeros((M,N))]),  
                # R (N,M), transpose to fit
                np.hstack([-np.eye(N), np.zeros((N, 1)), np.zeros((N, 1)), np.zeros((N, M)), np.eye(N), np.zeros((N, N))]),
                np.hstack([np.eye(N), np.zeros((N, 1)), np.zeros((N, 1)), np.zeros((N, M)), np.eye(N), np.zeros((N, N))]),
                np.hstack([np.zeros((1,N)), [[0]], [[-1]], [1/(self.params.confidence-1) * self.data.p.T], np.zeros((1,N)), np.zeros((1, N))]),
                np.hstack([np.eye(N), np.zeros((N, 1)), np.zeros((N, 1)), np.zeros((N, M)), np.zeros((N,N)), np.eye(N)]),
                np.hstack([-np.eye(N), np.zeros((N, 1)), np.zeros((N, 1)), np.zeros((N, M)), np.zeros((N,N)), np.eye(N)])
            ])

            # h vector
            h = np.hstack([np.zeros(M), np.zeros(N), np.zeros(N), [-self.params.cvar_limit], w_prev, -w_prev])            

            # Define A matrix and b vector
            A = np.vstack([
                np.hstack([np.ones((1, N)), [[1]], [[0]], np.zeros((1, M)), np.zeros((1, N)), np.zeros((1, N))]),
                np.hstack([np.zeros((1, N)), [[0]], [[0]], np.zeros((1, M)), np.ones((1, N)), np.zeros((1, N))]),
                np.hstack([np.zeros((1, N)), [[0]], [[0]], np.zeros((1, M)), np.zeros((1, N)), np.ones((1, N))]),
            ])
            
            A = np.vstack([A, -G])
            
            b = np.array([1, self.params.L_tar, self.params.T_tar])
            b = np.hstack([b, -h])
            self._equality_index = 3
            
            # Lower bound required for cuopt
            lower_bound_b = ['ninf' for _ in b]
            lower_bound_b[0] = 1 #self-financing
            
            # Variables constraints' lower and upper bounds
            lower = np.concatenate([np.full(N, self.params.w_min), [self.params.c_min], [-np.inf], np.full(M, 0), np.zeros(N), np.zeros(N)]) 
            upper = np.concatenate([np.full(N, self.params.w_max), [self.params.c_max], [np.inf], np.full(M, np.inf), np.full(N, self.params.w_max), np.full(N, self.params.T_tar)])

        # ------------------------------------------------------------------
        # Persist arrays so that solver back‑ends can access them later.
        # ------------------------------------------------------------------
        self._variable_size = lower.shape[0]
        self._A = A
        self._b = b
        self._d = d
        self._lower_bound_b = lower_bound_b
        self._lower = lower
        self._upper = upper     
        
    def solve_optimization_problem(self, device = 'CPU', gpu_settings = None, 
                                            cpu_settings = None,
                                            print_result = True, to_file = None): 
        """
        Set up and solve the CVaR optimization problem using the selected solver.

        Parameters
        ----------
        device : str, default 'CPU'. Which device/solver to use: 'CPU' (CVXPY) or 'GPU' (cuOpt).
        gpu_settings : cuOpt SolverSettings, optional. Settings to pass to cuOpt (only used if device == 'GPU').
        cpu_settings : dict, optional. Solver arguments for CVXPY (only used if device == 'CPU').
        print_result : bool, default True. Whether to print a formatted summary of results.
        to_file : tuple, optional. If provided, tuple (save_path, ticker_save_path) to serialize the LP problem for later (GPU) use.

        Returns
        -------
        result_row : pd.Series. Summary of regime, solver time, expected return, CVaR, and objective value.
        portfolio : Portfolio. The optimal portfolio found.
        
        Raises
        ------
        ValueError: If device is not recognized.
        """
        time_dict = {}
            
        device = device.upper()
        
        if device == 'CPU': 
            # Define the problem
            print('Solver: ' + cpu_settings['solver'])
            result_row, weights, cash = self._cpu_solve(cpu_settings)
                
        elif device == 'GPU':
            if to_file is not None:
                # time the write file process
                time_dict['write time'] = self._save_problem_for_cuopt(to_file)

            else:
                self._save_problem_for_cuopt()

            # solve the problem on gpu
            IO_start = time.time()
            result_row, weights, cash = self._gpu_solve(gpu_settings)
            IO_end = time.time()
            IO_time = IO_end - IO_start - result_row['solve time']
            time_dict['IO time'] = IO_time
                
        else: 
            raise ValueError('Invalid Device Name!')
        
        # ------------------------------------------------------------------
        # Wrap raw solution in a Portfolio helper ---------------------------
        # ------------------------------------------------------------------
        portfolio = Portfolio(name=device+'_optimal', tickers=self.tickers, weights=weights, cash=cash, time_range = self.regime_range)
        
        # Check whether the solutions satisfy self-financing
        portfolio._check_self_financing()
        
        if print_result: 
            self._print_CVaR_results(result_row, device, portfolio, time_dict)
            
        return result_row, portfolio
    
    def _cpu_solve(self, cpu_settings): 
        """
        Solve the assembled portfolio linear program on the **CPU** with CVXPY.
    
        Parameters
        ----------
        cpu_settings : dict
            A dictionary passed straight to ``cvxpy.Problem.solve``  
            (e.g., ``{"solver": cp.GUROBI, "verbose": True}``).  
            Any key accepted by CVXPY or the chosen solver is valid.
    
        Returns
        -------
        tuple
            (result_row, weights, cash)
    
            * **result_row** (pd.Series) – One row with columns
              ``self._result_columns`` containing  
              ``[regime_name, solve_time, expected_return, cvar, objective]``.
            * **weights** (np.ndarray) – Optimal asset weights (length ``n_assets``).
            * **cash** (float) – Optimal cash allocation (scalar).            
    
        Notes
        -----
        Internally this method
    
        1. Builds the CVXPY variables, objective, and constraints.
        2. Calls ``Problem.solve`` with the supplied ``cpu_settings``.
        3. Post-processes the raw solution vector ``x.value`` into user-friendly
           portfolio statistics and returns.
        """
        N = self.n_assets                   # Number of assets
        M = len(self.data.p)                # Number of scenario probabilities

        # Decision vector of size: assets + cash + auxiliary vars (t, u)
        x= cp.Variable(self._variable_size)

        # ---- Objective -------------------------------------------------------
        objective = cp.Minimize(self._d.T @ x)           # Linear (LP) objective
        # ---- Constraints -----------------------------------------------------
        constraints = [
            self._A[self._equality_index:] @ x <= self._b[self._equality_index:],
            self._A[:self._equality_index] @ x == self._b[:self._equality_index],
            self._lower <= x,
            x <= self._upper
        ]
        # Build the CVXPY Problem
        self._cpu_problem = cp.Problem(objective, constraints)

        # ---- Solve -----------------------------------------------------------
        result = self._cpu_problem.solve(**cpu_settings) # CVXPY returns objective
        # Extract portfolio statistics from the raw solution vector
        returns, cvar, weights, cash = self._process_optimization_results(x.value)

        # Assemble a tidy result row for later aggregation / display
        result_row = pd.Series([self.regime_name, self._cpu_problem.solver_stats.solve_time, 
                                returns, cvar, self._cpu_problem.value], index = self._result_columns)
        
        return result_row, weights, cash
    
    def _gpu_solve(self, settings = None):
        """
        Solve the same LP on **GPU** using cuOpt.
    
        Parameters
        ----------
        settings : lp.SolverSettings, optional
            cuOpt solver settings.  If *None*, a default ``lp.SolverSettings()``
            instance is created.
    
        Returns
        -------
        tuple
            (result_row, weights, cash) – Same structure as ``_cpu_solve``.
        """
        if settings is None: 
            settings = lp.SolverSettings()  # Fall back to default tuning

        # Launch the GPU solve
        solution = lp.Solve(self.cuOpt_model, settings)
        # cuOpt returns solve time in seconds
        solver_time = solution.get_solve_time()
        solver_solution = solution.get_primal_solution()
        # Translate raw vector -> portfolio metrics
        returns, cvar, weights, cash = self._process_optimization_results(solver_solution)
        
        obj = solution.get_primal_objective()
        result_row = pd.Series([self.regime_name, solver_time, 
                                returns, cvar, obj], index = self._result_columns)
        
        return result_row, weights, cash
    
    def _process_optimization_results(self, solver_solution): 
        """
        Convert the flat decision vector returned by the solver into
        interpretable portfolio metrics.
    
        Parameters
        ----------
        solver_solution : np.ndarray
            The full solution vector ``[w, cash, t, u]`` of length
            ``n_assets + 2 + num_scen``.
    
        Returns
        -------
        tuple
            (expected_return, cvar, weights, cash)
    
            * **expected_return** (float) – ``μᵀ w``.  
            * **cvar** (float) – Conditional Value-at-Risk at
              ``self.params.confidence``.  
            * **weights** (np.ndarray) – Asset weight vector (length ``n_assets``).  
            * **cash** (float) – Cash position.
        """
        weights = solver_solution[:self.n_assets]
        cash = solver_solution[self.n_assets]
        t = solver_solution[self.n_assets + 1]
        u = solver_solution[self.n_assets+2: self.n_assets + self.params.num_scen + 2]
        
        returns = self.data.mean @ weights
        cvar = t + (1 / (1-self.params.confidence) * self.data.p) @ u
        
        return returns, cvar, weights, cash
        
    def _print_CVaR_results(self, result_row, device, portfolio, time_dict, cut_off = 1e-3, rounding = 3): 
        """
        Pretty-print CVaR optimisation results and a cleaned weight vector.
    
        Parameters
        ----------
        result_row : pd.Series
            Row returned by ``_cpu_solve`` / ``_gpu_solve``.
        device : str
            'CPU' or 'GPU' (or any label to distinguish solver variants).
        portfolio : <portfolio object>
            An object exposing ``print_clean(verbose=True)``.
        time_dict : dict
            Additional timing breakdown (e.g., data prep, post-processing).
        cut_off : float, default 1e-3
            Weights with absolute value below this are treated as zero
            when printed.
        rounding : int, default 3
            Decimal places to display for numeric outputs.
    
        Returns
        -------
        tuple
            (weights, cash) – The *cleaned* optimal portfolio.  Currently the
            method only prints; it does **not** modify or return cleaned weights.
        """
        residual = 0
        # Display the results
        print('*************************')
        print('--- ' + device + ' CVaR Results---')
        print(f'{self.regime_name}: {self.regime_range}')
        print(f'Scenarios: {self.params.num_scen}')
        print("solver time: {:.4f} seconds".format(result_row['solve time']))
        for key, value in time_dict.items():
            print(f'{key}: {value :.4f} seconds')
        print('--- Optimal Portfolio ---' )    
        portfolio.print_clean(verbose = True)
        print('*************************\n')

    def _value_to_sdk_inf(self, value):
        """Converts various infinity representations to np.PINF/NINF."""
        if isinstance(value, str):
            if value.lower() == "inf": return np.inf
            if value.lower() == "ninf": return -np.inf
        if value == float('inf'): return np.inf
        if value == float('-inf'): return -np.inf
        if np.isposinf(value): return np.inf
        if np.isneginf(value): return -np.inf
        return float(value)
        
    def _sdk_list_to_float_array(self, data_list):
        """Converts a list (potentially with inf strings/objects) to a numpy float array with np.PINF/NINF."""
        return np.array([self._value_to_sdk_inf(v) for v in data_list], dtype=np.float64)
        
    def _save_problem_for_cuopt(self, to_file = None, file_format = None):
        """
        Populate a **cuOpt DataModel** from the in-memory NumPy/SciPy state and
        (optionally) persist it to disk.
    
        Parameters
        ----------
        to_file : tuple(str, str), optional
            ``(dir_path, base_name)`` – If supplied, the problem is serialized
            to ``dir_path / (base_name + FILE_FORMAT)`` in *msgpack* format,
            plus a companion ``tickers.json``.
        file_format : str, optional
            Overrides the global ``FILE_FORMAT`` (rarely used).
    
        Returns
        -------
        float or None
            Wall-clock **write time in seconds** if the model is saved,
            otherwise *None*.
        """
        dm = lp.DataModel()

        # Constraint matrix -------------------------------------------------
        csr_A = csr_matrix(self._A)
        dm.set_csr_constraint_matrix(
            csr_A.data.astype(np.float64),
            csr_A.indices.astype(np.int32),
            csr_A.indptr.astype(np.int32),
        )

        # Bounds ------------------------------------------------------------
        b = [cvar_utils.convert_to_compliant(value) for value in self._b]
        np_constraint_ub = self._sdk_list_to_float_array(b)
        np_constraint_lb = self._sdk_list_to_float_array(self._lower_bound_b)
        dm.set_constraint_bounds(np_constraint_ub)
        dm.set_constraint_lower_bounds(np_constraint_lb)
        dm.set_constraint_upper_bounds(np_constraint_ub)

        # Objective ---------------------------------------------------------
        dm.set_objective_coefficients(np.asarray(self._d.tolist(), dtype=np.float64))
        dm.set_objective_scaling_factor(1.0)
        dm.set_objective_offset(0.0)

        # Variable bounds ---------------------------------------------------
        upper = [cvar_utils.convert_to_compliant(value) for value in self._upper]
        lower = [cvar_utils.convert_to_compliant(value) for value in self._lower]
        dm.set_variable_lower_bounds(self._sdk_list_to_float_array(lower))
        dm.set_variable_upper_bounds(self._sdk_list_to_float_array(upper))

        # Problem is a minimization -----------------------------------------
        dm.set_maximize(False)

        self.cuOpt_model = dm # Store the DataModel instance

        # =====================================================================
        # Optional: write to disk ---------------------------------------------
        # =====================================================================
        if to_file is not None:
            write_start = time.time()
            
            # Build paths
            save_path = utils.create_save_path(to_file[0], to_file[1] + FILE_FORMAT)
            ticker_save_path = utils.create_save_path(to_file[0], 'tickers.json')

            # Serialize the model with cuOpt's built-in parser
            problem_dict_to_save = lp_parser.toDict(dm, json=True)
            # Use cuOpt parser to parse data_model before saving
            model_json = json.dumps(problem_dict_to_save, indent=4)
            model_data = json.loads(model_json)
            with open(save_path, 'wb') as out:
                msgpack.dump(problem_dict_to_save, out)

            if not os.path.exists(ticker_save_path):
                ticker_json = json.dumps(list(self.tickers), indent = 4)
                with open(ticker_save_path, 'w') as file:
                    file.write(ticker_json)
            write_end = time.time()
            
            write_time = write_end - write_start 
            
            return write_time
        
    def read_problem_from_file(self):
        """
        Re-hydrate a previously saved cuOpt problem from disk
        into the in-memory attributes used by this class.
    
        Files expected
        -------------
        * ``<self.problem_from_file + FILE_FORMAT>`` – msgpack model file.
        * Companion ``tickers.json`` (optional, not read here).
    
        Side Effects
        ------------
        Overwrites the following attributes:
    
        * ``self._A``  – csr_matrix of constraints  
        * ``self._b``  – RHS vector  
        * ``self._lower_bound_b`` – Lower bounds (if present)  
        * ``self._d``  – Objective coefficients  
        * ``self._upper`` / ``self._lower`` – Variable bounds
        """
        with open(self.problem_from_file + FILE_FORMAT, 'rb') as f:
            opt_problem = msgpack.load(f)

        # Extract csr_constraint_matrix data and reconstruct the csr_matrix
        offsets = np.array(opt_problem['csr_constraint_matrix']['offsets'])
        indices = np.array(opt_problem['csr_constraint_matrix']['indices'])
        values = np.array(opt_problem['csr_constraint_matrix']['values'])

        # Reconstruct the csr_matrix
        self._A = csr_matrix((values, indices, offsets))

        # Access the constraint bounds
        self._b = opt_problem['constraint_bounds']['bounds']
        self._lower_bound_b = opt_problem['constraint_bounds']['lower_bounds']

        # Access the objective data
        self._d = np.array(opt_problem['objective_data']['coefficients'])

        # Access variable bounds
        upper = opt_problem['variable_bounds']['upper_bounds']
        lower = opt_problem['variable_bounds']['lower_bounds']
        
        self._upper = [cvar_utils.convert_from_file(value) for value in upper]
        self._lower = [cvar_utils.convert_from_file(value) for value in lower]
